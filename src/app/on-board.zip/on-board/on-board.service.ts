import { Injectable } from "@angular/core";
import { Observable } from "rxjs/Observable";
import "rxjs/add/operator/map";
import "rxjs/add/operator/catch";
import "rxjs/add/observable/throw";
import { LoginService } from "../shared/services/login.service";
import { AppService } from "../app.service";
import Swal from "sweetalert2";
import { HttpClient, HttpResponse } from "@angular/common/http";

@Injectable({
  providedIn: "root",
})
export class OnBoardService {
  isLoading: boolean = false;
  cashflowEmpty = true;
  stateMap = new Map();
  isVerification: boolean = false;
  profileData: any;
  state: any;
  linkProfileCount = 0;
  fields = [];
  documents = [];
  cashFlowDetails: any;
  public profileId: any;
  public verifyDetails: any;
  public onboardDetails: any;
  public workflowTemplateID = 0;
  public access_token: any;
  public workFlowID: any;
  public workFlowName: any;
  public workFlowTemplateDetails: any;
  public profileBaseUrl: any;
  public cashFlowDetailsData: any;
  public creditBureauData: any;
  public creditScoreData: any;
  public profileStatus: any;
  public detailsId: any;
  public stepIndex: any = 0;
  public linkedProfiles = [];
  reportURL;

  private baseUrl = this.appService.mffURL + "/mff/api";

  constructor(
    private _httpClient: HttpClient,
    private loginService: LoginService,
    private appService: AppService
  ) {
    this.access_token = loginService.access_tokenMethod();
    this.reportURL =
      this.appService.mffURL + ":8686/highmark/getHighmarkVerification/";
  }

  profilePort() {
    return (this.profileBaseUrl =
      this.appService.mffURL +
      ":" +
      this.loginService.portnumber() +
      "/WorkflowService");
  }

  getWorkflowByID(workflowID) {
    return this._httpClient
      .get(`${this.profilePort()}/workflows/${workflowID}`)
      .map((res: HttpResponse<any>) => res)
      .catch(this.errorHandler);
  }

  getSocialResult(profileID) {
    return this._httpClient
      .get(
        `${this.appService.mffURL}/:7001/thirdpartyservices/neenar/result//${profileID}`
      )
      .map((res: HttpResponse<any>) => res)
      .catch(this.errorHandler);
  }

  getWorkflows() {
    return this._httpClient
      .get(`${this.profilePort()}/workflows`)
      .map((response: HttpResponse<any>) => response)
      .catch(this.errorHandler);
  }

  verifyAadharID(payload) {
    return this._httpClient
      .post(`${this.appService.THIRD_PARTY_URL}/okyc/otp/request`, payload)
      .map((res: HttpResponse<any>) => {
        return res;
      })
      .catch(this.errorHandler);
  }

  verifyAadharOTP(payload) {
    return this._httpClient
      .post(`${this.appService.THIRD_PARTY_URL}/okyc/otp/verify`, payload)
      .map((res: HttpResponse<any>) => {
        return res;
      })
      .catch(this.errorHandler);
  }

  getAMLResult(payload) {
    return this._httpClient
      .post(`${this.appService.THIRD_PARTY_URL}/shufti`, payload,{
        observe:'body',
        responseType:'json'
      })
      .map((res) => {
        return res;
      })
      .catch(this.errorHandler);
  }

  checkProfileLinked(filterData, workFlowID, pageNumber, noOfRecords) {
    return this._httpClient
      .get(
        this.profilePort() +
          "/unlinkedProfiles/" +
          workFlowID +
          "?pageNumber=" +
          pageNumber +
          "&numberOfRecords=" +
          noOfRecords +
          (filterData.Identifier
            ? "&Identifier=" + filterData.Identifier
            : "") +
          (filterData.Name ? "&Name=" + filterData.Name : "") +
          (filterData.NationalID
            ? "&nationalId=" + filterData.NationalID
            : "") +
          (filterData.Hierarchy ? "&Hierarchy=" + filterData.Hierarchy : "")
      )
      .map((res: HttpResponse<any>) => {
        return res["data"]["workflow"];
      })
      .catch(this.errorHandler);
  }

  checkProfileLinkedToWorkflow(profileId) {
    return this._httpClient
      .get(`${this.profilePort()}/linkedWorkflows/${profileId}`)
      .map((res: HttpResponse<any>) => res);
  }

  getWorkflowTemplatesByID(workFlowTemplateId) {
    return this._httpClient
      .get(`${this.profilePort()}/workflowTemplates/${workFlowTemplateId}`)
      .map((res: HttpResponse<any>) => res["data"]["workflow"])
      .catch(this.errorHandler);
  }

  attachWorkflowToProfile(workFlowTemplate) {
    return this._httpClient
      .post(`${this.profilePort()}/workflowToProfiles`, workFlowTemplate)
      .map((res: HttpResponse<any>) => res)
      .catch(this.errorHandler);
  }

  getUnlinkedProfiles(workFlowID, pageNumber, noOfRecords) {
    return this._httpClient
      .get(
        `${this.profilePort()}/unlinkedProfileIds/${workFlowID}?pageNumber=${pageNumber}&numberOfRecords=${noOfRecords}`
      )
      .map((res: HttpResponse<any>) => res["data"]["workflow"])
      .catch(this.errorHandler);
  }

  getWorkflowTemplateByWorkflowProfileID(workFlowProfileId) {
    return this._httpClient
      .get(
        `${this.profilePort()}/templateDetailsByworkflowProfileId/${workFlowProfileId}`
      )
      .map((res: HttpResponse<any>) => {
        return res["data"]["workflow"];
      })
      .catch(this.errorHandler);
  }

  getWorkflowTemplateDetails1(
    workFlowID,
    verified,
    pageNumber,
    noOfRecords,
    profileids
  ) {
    return this._httpClient
      .get(
        this.profilePort() +
          "/workflow/workflowTemplateDetails/" +
          workFlowID +
          "/" +
          verified +
          "?" +
          (noOfRecords ? "&numberOfRecords=" + noOfRecords : "") +
          (pageNumber ? "&pageNumber=" + pageNumber : "") +
          (profileids.length > 0 ? "&profileIds=" + profileids : "")
      )
      .map((res: HttpResponse<any>) => {
        return res["data"]["workflow"];
      })
      .catch(this.errorHandler);
  }

  getWorkflowTemplateDetailsByID(workFlowID) {
    return this._httpClient
      .get(`${this.profilePort()}/workflowTemplateDetails/${workFlowID}`)
      .map((res: HttpResponse<any>) => res["data"]["workflow"])
      .catch(this.errorHandler);
  }

  getTemplateID(detailsID) {
    return this._httpClient
      .get(`${this.profilePort()}/workflowTemplateDetails/${detailsID}`)
      .map((res: HttpResponse<any>) => res)
      .catch(this.errorHandler);
  }

  updateWorkflowTemplateDetails(
    WorkflowTemplateDetailsID,
    WorkflowTemplateDetails
  ) {
    return this._httpClient
      .put(
        `${this.profilePort()}/workflowTemplateDetails/${WorkflowTemplateDetailsID}`,
        WorkflowTemplateDetails
      )
      .map((res: HttpResponse<any>) => res)
      .catch(this.errorHandler);
  }

  updateScoreme(payload) {
    return this._httpClient
      .post(`${this.appService.THIRD_PARTY_URL}/upload/bankStatement`, payload)
      .map((res: HttpResponse<any>) => res)
      .catch(this.errorHandler);
  }

  saveScoremeReport(requestParams) {
    return this._httpClient
      .get(
        `${this.appService.THIRD_PARTY_URL}/download/report?profileId=${requestParams.profileId}&referenceId=${requestParams.referId}`
      )
      .map((res: HttpResponse<any>) => res)
      .catch(this.errorHandler);
  }

  getPovertyResult(templateID) {
    return this._httpClient
      .get(`${this.profilePort()}/pplScore/${templateID}`)
      .map((res: HttpResponse<any>) => res)
      .catch(this.errorHandler);
  }

  sendSocialLink(json) {
    return this._httpClient
      .post(`${this.appService.mffURL}:7001/thirdpartyservices/sendsms`, json)
      .map((res: HttpResponse<any>) => res)
      .catch(this.errorHandler);
  }

  verifyWorkflowTemplateDetails(WorkflowTemplateDetails) {
    return this._httpClient
      .put(
        `${this.profilePort()}/workflowTemplateDetails/verify`,
        WorkflowTemplateDetails
      )
      .map((res: HttpResponse<any>) => res)
      .catch(this.errorHandler);
  }

  getCreditReport(templateID) {
    // return this._http.get(this.reportURL + templateID).map((res) => {
    //   const contentType = res.headers.get("Content-type");
    //   if (contentType == "application/json") {
    //     return res.json();
    //   } else if (contentType == "text/html") {
    //     return res.text();
    //   }
    // });

    return this._httpClient
      .get(`${this.reportURL}${templateID}`)
      .map((res: HttpResponse<any>) => res)
      .catch(this.errorHandler);
  }

  approveProfiles(WorkflowDetailsID) {
    return this._httpClient
      .get(`${this.profilePort()}/approvalProfile/${WorkflowDetailsID}`)
      .map((res: HttpResponse<any>) => res)
      .catch(this.errorHandler);
  }

  errorHandler(error) {
    this.linkProfileCount = 0;
    let errorMessage = JSON.parse(error._body);
    if (errorMessage.message) {
      this.linkProfileCount = 0;
      // Swal.fire({
      //   title: "Sorry!",
      //   text: errorMessage.message,
      //   type: "warning",
      // });
    }
    return Observable.throw(error || " server error ");
  }
}
