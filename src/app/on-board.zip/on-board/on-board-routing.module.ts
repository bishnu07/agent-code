import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { OnBoardComponent } from "./on-board.component";
import { OnBoardDetailsComponent } from "./on-board-details/on-board-details.component";
import { CashflowComponent } from "./on-board-details/cashflow/cashflow.component";
import { KYCEditComponent } from "./on-board-details/kyc-edit/kyc-edit.component";
import { CamelcasePipe } from "./camelcase.custom.pipe";
import { DocumentVerificationComponent } from "./document-verification/document-verification.component";

const routes: Routes = [
  {
    path: "",
    children: [
      {
        path: "boards/:id",
        component: OnBoardComponent,
      },
      {
        // path: 'onBoard/:id',
        path: ":id",
        component: OnBoardDetailsComponent,
      },
      {
        path: "WorkflowDetails",
        component: CashflowComponent,
      },
      {
        path: "WorkFlowDetails",
        component: KYCEditComponent,
      },
      {
        path: "Verification",
        component: DocumentVerificationComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OnBoardRoutingModule {}
export const routedComponents = [
  OnBoardComponent,
  OnBoardDetailsComponent,
  CashflowComponent,
  CamelcasePipe,
  KYCEditComponent,
];
