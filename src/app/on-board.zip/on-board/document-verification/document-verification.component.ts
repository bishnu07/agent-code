import { Component, OnInit } from "@angular/core";
import { LoginService } from "app/shared/services/login.service";
import { ProfileService } from "app/profiles/profile.service";
import { OnBoardService } from "../on-board.service";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: "app-document-verification",
  templateUrl: "./document-verification.component.html",
  styleUrls: ["./document-verification.component.scss"],
})
export class DocumentVerificationComponent implements OnInit {
  show: boolean = true;
  selectedFile: any;
  EXCEL_TYPE = "application/json";
  today = new Date().toISOString();

  constructor(
    public loginService: LoginService,
    public _profileService: ProfileService,
    public service: OnBoardService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      let ref = {
        reference: params["reference"],
      };
      const access_token = params["access_token"];
      const profileId = params["profileId"];
      let frmData = {};
      this._profileService
        .uploadFilesToProfile(
          params["profileId"],
          "business",
          frmData,
          params["access_token"]
        )
        .subscribe((file) => {});
      this.loginService.checkDocumentVerification(ref).subscribe((res) => {
        let msg = res["message"].event;
        if (msg == "verification.accepted") {
          this.show = true;
        } else if (msg != "verification.accepted") {
          this.show = false;
        }
      });
    });
  }
  saveOtpTransaction(
    jsonObject: any,
    fileName: string,
    profileId: any,
    access_token
  ) {
    this.saveAsJsonFile(jsonObject, "business");
    var frmData = new FormData();
    frmData.append(
      "files",
      this.selectedFile,
      fileName +
        "_" +
        this.today.split("T")[0] +
        " " +
        this.today.split("T")[1].split(".")[0] +
        "." +
        this.selectedFile.name.split(".")[1]
    );
    this._profileService
      .uploadFilesToProfile(profileId, "business", frmData, access_token)
      .subscribe((file) => {});
  }

  private saveAsJsonFile(jsonObject: object, fileName: string) {
    const data: Blob = new Blob([JSON.stringify(jsonObject)], {
      type: this.EXCEL_TYPE,
    });
    let file = new File([data], fileName + ".json");
    this.selectedFile = file;
    return;
  }
}
