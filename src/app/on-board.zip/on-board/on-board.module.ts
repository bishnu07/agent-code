import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
// import { CustomFormsModule } from "ng2-validation";
import { MatchHeightModule } from "../shared/directives/match-height.directive";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import {
  OnBoardRoutingModule,
  routedComponents,
} from "./on-board-routing.module";
import { Ng2SmartTableModule } from "ng2-smart-table";
import { MatStepperModule } from "@angular/material/stepper";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatTableModule } from "@angular/material/table";
import { MatCheckboxModule } from "@angular/material/checkbox";
import { OnBoardService } from "./on-board.service";
import {
  SafePipe,
  CashflowComponent,
} from "./on-board-details/cashflow/cashflow.component";
import { ProfileService } from "../profiles/profile.service";
import { MatPaginatorModule } from "@angular/material/paginator";
import { MatSortModule } from "@angular/material/sort";
import { KeysPipe } from "./on-board.custom.pipe";
import { ExpandMode, NgxTreeSelectModule } from "ngx-tree-select";
import { CamelcasePipe } from "./camelcase.custom.pipe";
import { ExportAsService } from "ngx-export-as";
import { DocumentVerificationComponent } from "./document-verification/document-verification.component";
import { CreditBureauComponent } from "./on-board-details/credit-bureau/credit-bureau.component";
import { CreditScoreComponent } from "./on-board-details/credit-score/credit-score.component";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    // CustomFormsModule,
    MatchHeightModule,
    NgbModule,
    OnBoardRoutingModule,
    Ng2SmartTableModule,
    MatFormFieldModule,
    MatCheckboxModule,
    MatStepperModule,
    NgxTreeSelectModule.forRoot({
      idField: "branchid",
      textField: "branch_name",
      expandMode: ExpandMode.Selection,
    }),
  ],
  declarations: [
    ...routedComponents,
    SafePipe,
    CamelcasePipe,
    KeysPipe,
    CreditBureauComponent,
    CreditScoreComponent,
    DocumentVerificationComponent,
  ],
  providers: [
    OnBoardService,
    ProfileService,
    KeysPipe,
    CamelcasePipe,
    ExportAsService,
    CashflowComponent,
  ],
  exports: [CamelcasePipe, KeysPipe],
})
export class OnBoardModule {}
