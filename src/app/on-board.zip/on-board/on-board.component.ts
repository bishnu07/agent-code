import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { OnBoardService } from './on-board.service';
@Component({
  selector: 'app-on-board',
  // templateUrl: './on-board.component.html',
  // styleUrls: ['./on-board.component.scss']
  template: `
 <div>
   Showing product details for product: {{id}}
 </div>
`,
})
export class OnBoardComponent implements OnInit, OnDestroy {
  id: any;
  private sub: any;
  constructor(private route: ActivatedRoute, private onBoardService: OnBoardService) {

  }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.id = +params['id'];
      this.onBoardService.getWorkflowByID(this.id).subscribe(data => {
        alert(JSON.stringify(data));
        this.onBoardService.workFlowTemplateDetails = data;
      })
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
