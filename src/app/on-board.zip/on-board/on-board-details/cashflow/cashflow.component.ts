import { Component, OnInit } from "@angular/core";
import { OnBoardService } from "../../on-board.service";
import { Router } from "@angular/router";
import { ProfileService } from "../../../profiles/profile.service";
import { PipeTransform, Pipe } from "@angular/core";
import { DomSanitizer } from "@angular/platform-browser";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { ExportAsService, ExportAsConfig } from "ngx-export-as";
import { NgxXml2jsonService } from "ngx-xml2json";
import Swal from "sweetalert2";
import { LoginService } from "app/shared/services/login.service";
import { forkJoin } from "rxjs";
import { take } from "rxjs/operators";
import { AppService } from "app/app.service";
import { FileSizePipe } from "app/shared/pipes/filesize.pipe";

@Pipe({ name: "safe" })
export class SafePipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) {}
  transform(url) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}

@Component({
  selector: "app-cashflow",
  templateUrl: "./cashflow.component.html",
  styleUrls: ["./cashflow.component.scss"],
})
export class CashflowComponent implements OnInit {
  EXCEL_TYPE =
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
  EXCEL_EXTENSION = ".xlsx";
  aadhaarID: number | boolean = true;
  aadhaarOtp: number | boolean = true;
  amlDate: any | boolean = true;
  amlName: number | boolean = true;
  fileds = [];
  dispreport = false;
  cashFlowDetailsData: any = {};
  cashFlowDetails: any = {};
  isCashflowData: boolean = false;
  fileSizeExceeded = false;
  imageFiles: any;
  imageFilesBundle: any;
  data: any;
  cashflowEmpty: boolean = true;
  verifyObj: any = {};
  profileDetails;
  today = new Date().toISOString();
  documents = [];
  report: any;
  config: ExportAsConfig = {
    type: "pdf",
    elementId: "report",
  };
  reportHtml;
  reportURL: string;
  stepPosition: number = 0;
  workflowClientDetails: any;
  socialResult: any;
  neenerTooltips = {
    "Default Risk":
      "This is used in both Rejection Recapture and Default Reduction. This result measures: WILL the consumer pay you back, not can they pay you back. It’s tuned to the Lenders unique risk threshold and is delivered as a binary outcome (will pay/won’t pay) or as Json which reflects the binary outcome. Scale is 0 – 100. The higher the number, the higher the default risk. The lower the number, the lower the default risk",
    "Fico Alignment":
      "This result projects a predicted FICO score based on their authentic payment tendencies and is delivered as a ternary outcome (sub-prime, prime, super prime) or as Json which reflects the ternary outcome. Scale is 0 – 100. The lower the number the lower the “projected” correlated FICO.",
    Transactor:
      "This result measures, on a revolving credit line, is this someone likely to pay minimum balances every month or pay in full every month. Or on installment loans, is this a consumer likely to make the payment early, on-time, or late. This is tuned to the Lenders unique risk threshold. It is delivered as a binary outcome (Transactor/Revolver) or as Json which reflects the binary outcome. Scale is 0 – 100. The lower the number the higher the likelihood of being a Revolver. The higher the number the higher the likelihood of being a Transactor.",
    Resilience:
      "This result measures how likely the consumer is to overcome certain life events that typically destroy traditional credit scores such as Job Loss, Illness, Divorce, Natural Disaster (pandemics, etc.) It’s tuned to the Lenders unique risk threshold. It is delivered as a binary outcome (High Resiliency/Low Resiliency) or as Json which reflects the binary outcome. Scale is 0 – 100. The lower the number, the lower the consumer’s Resiliency, the higher the number the higher the consumer’s Resiliency.",
    Veracity:
      "Veracity = Truthfulness. This result measure’s how likely the consumer is Over-Claiming or Under-Claiming overall information on their loan application, i.e., generally providing misleading information. It is delivered as a binary outcome (High Veracity/Low Veracity) or as Json which reflects the binary outcome. Scale is 0 – 100.   The lower the number, the lower the consumer’s truthfulness, the higher the number the higher the consumer’s truthfulness.",
    "Early Payoff":
      "This is a measure highly correlated with Transactor-Revolver and measures the likelihood on an installment loan to pay off-early or on a revolving line of credit to make the payment early. Scale is 0 – 100.   The lower the number, the lower the consumer’s likelihood of early payoff, the higher the number the higher the likelihood of early payoff.",
  };
  workflowFormTemplate: any;
  highmark = {
    "Loan Amount": "",
    "Name one": "",
    "Date of birth": "",
    "Type of relation": "",
    "Name of relation": "",
    "Key person type": "",
    "Key person name": "",
    "Nominee type": "",
    "Nominee name": "",
    "Telephone number": "",
    "Type of identifier(primary)": "",
    "Value of identifier(primary)": "",
    "Address one": "",
    City: "",
    State: "",
    Pin: "",
    Email: "",
    CreditInquiryPurposeTypeDesc: "",
    "Member identifier": "",
    "Kendra identifier": "",
    "Branch Id": "",
    "Type of identifier(secondary)": "",
    "Value of identifier(secondary)": "",
  };
  map = new Map();
  mapType = new Map();

  constructor(
    private onBoardService: OnBoardService,
    private modalService: NgbModal,
    private appService: AppService,
    public ngxXml2jsonService: NgxXml2jsonService,
    private _router: Router,
    private _profileService: ProfileService,
    private sanitizer: DomSanitizer,
    private exportAsService: ExportAsService,
    private loginService: LoginService,
    private fileSize: FileSizePipe
  ) {}

  ngOnInit() {
    this.imageFilesBundle = [];
    this.profileDetails = this.onBoardService.profileId;
    this.verifyObj = {};
    this.fileds = [];
    this.data = this.onBoardService.profileStatus;
    this.onBoardService.profileId;
    this.reportURL =
      this.onBoardService.reportURL +
      JSON.parse(this.onBoardService.onboardDetails);

    this._profileService
      .getFileList(this.onBoardService.profileId.profileID, "business")
      .subscribe((files) => {
        if (files.length > 0) {
          this.documents = files.map((file) => file.fileName);
          this.onBoardService.documents = this.documents;
        }
      });
    let onBoardDetailsID = JSON.parse(this.onBoardService.onboardDetails);
    this.onBoardService
      .getWorkflowTemplateDetailsByID(onBoardDetailsID)
      .subscribe((data) => {
        if (this.isEmpty(data["workflowTemplateDetails"])) {
          this.cashflowEmpty = true;
          this.onBoardService.cashflowEmpty = true;
        } else {
          this.cashflowEmpty = false;
          this.onBoardService.cashflowEmpty = false;
        }
        !this.cashflowEmpty
          ? (this.workflowClientDetails = data.workflowTemplateDetails)
          : "";
        this.onBoardService
          .getWorkflowTemplatesByID(data["templateID"])
          .subscribe((element) => {
            this.workflowFormTemplate = element;
            if (element["workFlowTemplates"]["Form Header"]) {
              element["workFlowTemplates"]["Form Header"].forEach(
                (questions) => {
                  this.cashflowEmpty
                    ? (this.cashFlowDetails[questions.Label] = "")
                    : "";
                  this.fileds.push(questions);
                }
              );
              this.fileds.forEach((field) => {
                if (!this.cashFlowDetails.hasOwnProperty(field.Label))
                  this.cashFlowDetails[field.Label] = "";
              });
            }
            if (element["workFlowTemplates"]["Form Body"]) {
              element["workFlowTemplates"]["Form Body"].forEach((questions) => {
                this.cashflowEmpty
                  ? (this.cashFlowDetails[questions.Label] = "")
                  : "";
                if (questions.Type == "Json") {
                  questions["Value"] = JSON.parse(questions.Value);
                  this.fileds.push(questions);
                } else {
                  this.fileds.push(questions);
                }
              });
            }
            if (
              (this.onBoardService.profileStatus.includes(
                "API-CreditBureau_CRIFHM"
              ) ||
                this.onBoardService.profileStatus.includes(
                  "CreditBureau_CRIFHM"
                )) &&
              this.workflowClientDetails != ""
            ) {
            } else {
            }
            this.fileds.forEach((lb) => {
              if (
                this.cashFlowDetails[lb["Label"]] &&
                lb.Type == "Json" &&
                lb.Value.length > 0
              ) {
                let data = lb.Value.filter(
                  (flb) => flb.code == this.cashFlowDetails[lb.Label]
                );
                data.forEach((flb) => {
                  this.fileds.forEach((f) => {
                    if (f.Label == flb.dependency) {
                      Object.assign(f, { Value: flb.children });
                      data = flb.children;
                    }
                  });
                });
              }
            });
            this.onBoardService.cashFlowDetails = this.cashFlowDetails;
            this.stepPosition = 1;
            this.onBoardService.fields = this.fileds;
            let check = this.onBoardService.fields.filter(
              (label) => label.Label == "ID Verification"
            );
            if (check.length > 0) {
              this.onBoardService.isVerification = true;
            } else {
              this.onBoardService.isVerification = false;
            }
          });
        !this.cashflowEmpty
          ? (this.cashFlowDetails = data["workflowTemplateDetails"])
          : "";
        this.verifyObj["workflowTemplateDetails"] = [];
        this.verifyObj["workflowTemplateDetails"].push(data);
        for (var key in this.verifyObj["workflowTemplateDetails"][0]) {
          if (key !== "templateDetailsID") {
            if (key !== "templateID") {
              if (key !== "workflowProfileID") {
                delete this.verifyObj["workflowTemplateDetails"][0][key];
              }
            }
          }
        }
      });
  }

  isEmpty(obj) {
    for (var key in obj) {
      if (obj.hasOwnProperty(key)) return false;
    }
    return true;
  }

  openAMLResult(form) {
    this.fileds.forEach((el) => {
      if (el["Type"] == "Shuftipro-AMLI-DOB") {
        this.amlDate = form[el["Label"]] ? form[el["Label"]] : false;
      } else if (el["Type"] == "Shuftipro-AMLI-Name") {
        this.amlName = form[el["Label"]] ? form[el["Label"]] : false;
      }
    });
    if (this.amlDate && this.amlName) {
      let json = {
        reference: this.onBoardService.profileId.profileID,
        background_checks: {
          name: {
            full_name: this.amlName,
          },
          dob: this.amlDate,
        },
      };

      this.onBoardService.getAMLResult(json).subscribe(
        (res) => {
          let response = res.message;
          for (const key in response) {
            response[key] == null ? (response[key] = "") : "";
          }
          Swal.fire({
            title: "",
            text: response["declined_reason"],
            icon: "success",
          });
          this.saveOtpTransaction(response, "AML");
          let onBoardDetailsID = JSON.parse(this.onBoardService.onboardDetails);
          this.onBoardService
            .updateWorkflowTemplateDetails(onBoardDetailsID, form)
            .subscribe((data) => {});
        },
        (error) => {
          let response = JSON.parse(error._body);
          this.saveOtpTransaction(response.message, "AML");
          Swal.fire({
            title: "Error",
            text: response.message["message"],
            icon: "error",
          });
        }
      );
    }
  }

  saveOtpTransaction(jsonObject: any, fileName?: string) {
    this.saveAsJsonFile(jsonObject, "business");
    var frmData = new FormData();
    frmData.append(
      "files",
      this.selectedFile,
      fileName +
        "_" +
        this.today.split("T")[0] +
        " " +
        this.today.split("T")[1].split(".")[0] +
        "." +
        this.selectedFile.name.split(".")[1]
    );
    this._profileService
      .uploadFilesToProfile(
        this.onBoardService.profileId.profileID,
        "business",
        frmData
      )
      .subscribe((file) => {
        this.selectedFile = "";
        this._profileService
          .getFileList(this.onBoardService.profileId.profileID, "business")
          .subscribe((files) => {
            if (files) {
              this.documents = files.map((file) => file.fileName);
            }
          });
      });
  }

  private saveAsJsonFile(jsonObject: object, fileName: string) {
    this.EXCEL_TYPE = "application/json";
    const data: Blob = new Blob([JSON.stringify(jsonObject)], {
      type: this.EXCEL_TYPE,
    });
    let file = new File([data], "aadhaar.json");
    this.selectedFile = file;
  }

  openReport(modal) {
    this.onBoardService
      .getCreditReport(JSON.parse(this.onBoardService.onboardDetails))
      .subscribe(
        (res: any) => {
          this.modalService.open(modal, {
            windowClass: "reportModal",
          });
        },
        (error) => {
          let errorMessage = JSON.parse(error._body);
          var errors = "";
          errorMessage.forEach((err) => {
            errors += "<br>" + err.description + "<br>";
          });
          Swal.fire({
            title: "Could not generate report",
            html: errors,
            icon: "error",
          });
        }
      );
  }

  openSocialResult(modal, form) {
    if (form["Result"]) {
      let storedForm = form["Result"];
      this.socialResult = [];
      Object.keys(storedForm).forEach((key) => {
        let thisKey = key
          .replace(/([A-Z])/g, " $1")
          .replace(/^./, function (str) {
            return str.toUpperCase();
          });
        this.socialResult.push({
          Label: thisKey,
          Value: storedForm[key],
          Tooltip: this.neenerTooltips[thisKey]
            ? this.neenerTooltips[thisKey]
            : "",
        });
      });
      this.modalService.open(modal);
    } else {
      this.onBoardService
        .getSocialResult(this.onBoardService.profileId.profileID)
        .subscribe((res) => {
          if (res.errorMessage) {
            Swal.fire({
              title: "Sorry",
              html: "Result Not Generated",
              icon: "error",
            });
          } else {
            this.socialResult = [];
            this.cashFlowDetails["Result"] = res;
            Object.keys(res).forEach((key) => {
              let thisKey = key
                .replace(/([A-Z])/g, " $1")
                .replace(/^./, function (str) {
                  return str.toUpperCase();
                });
              this.socialResult.push({
                Label: thisKey,
                Value: res[key],
                Tooltip: this.neenerTooltips[thisKey]
                  ? this.neenerTooltips[thisKey]
                  : "",
              });
            });
            this.modalService.open(modal);
            form["Result"] = res;
            let onBoardDetailsID = JSON.parse(
              this.onBoardService.onboardDetails
            );
            this.onBoardService
              .updateWorkflowTemplateDetails(onBoardDetailsID, form)
              .subscribe((data) => {});
          }
        });
    }
  }

  printReport() {
    this.config.type = "pdf";
    this.config.options = {
      jsPDF: {
        unit: "in",
        format: "ledger",
        orientation: "portrait",
        putOnlyUsedFonts: true,
      },
      image: { type: "jpeg", quality: 1 },
    };
    this.dispreport = true;
    this.exportAsService.save(this.config, "Highmark").subscribe(() => {
      setTimeout(() => {
        this.dispreport = false;
      }, 20);
    });
  }

  onSubmit(workFlows: any) {
    if (JSON.stringify(workFlows) != "{}") {
      var errorCount = 0;
      if (
        this.onBoardService.profileStatus.includes("API-CreditBureau_CRIFHM") ||
        this.onBoardService.profileStatus.includes("CreditBureau_CRIFHM")
      ) {
        for (const key in workFlows) {
          !workFlows[key] ? errorCount++ : "";
        }
        if (errorCount > 0) {
          Swal.fire({
            title: ``,
            html: '<h5 class="swal-msg-font swal-text-font">Please fill all fields</h5>',
            showConfirmButton: true,
            focusConfirm: true,
            confirmButtonColor: this.loginService.theme,
            confirmButtonText: '<span class=""  style="color:white;">Ok</span>',
            icon: "error",
          });
        } else {
          let onBoardDetailsID = JSON.parse(this.onBoardService.onboardDetails);
          this.onBoardService
            .updateWorkflowTemplateDetails(onBoardDetailsID, workFlows)
            .subscribe((data) => {
              Swal.fire({
                title: ``,
                html: `<h5 class="swal-msg-font swal-text-font">${data["message"]}</h5>`,
                showConfirmButton: true,
                focusConfirm: true,
                confirmButtonColor: this.loginService.theme,
                confirmButtonText:
                  '<span class="" style="color:white;">Ok</span>',
                icon: "success",
              });
              if (data["message"] == "Approval is pending") {
                this._router.navigate(["/account/profile-loan-details"]);
              }
            });
        }
      } else if (this.onBoardService.profileStatus.includes("Bank Analyzer")) {
        let onBoardDetailsID = JSON.parse(this.onBoardService.onboardDetails);
        let frmData = new FormData();
        if (this.selectedScoremeFile) {
          const payload = {
            entityType: workFlows["Entity Types"],
            bankCode: workFlows["Bank Names"],
            accountType: workFlows["Account Types"],
            accountNumber: workFlows["Account Number"],
          };
          const label = "score_me";
          frmData.append(
            "file",
            this.selectedScoremeFile,
            label +
              "_" +
              this.today.split("T")[0] +
              " " +
              this.today.split("T")[1].split(".")[0] +
              "." +
              this.selectedScoremeFile.name.split(".")[1]
          );
          frmData.append(
            "profileId",
            this.onBoardService.profileId["profileID"]
          );
          frmData.append(
            "workflowProfileId",
            this.onBoardService.profileId["workflowProfileID"]
          );
          frmData.append("accountDetails", JSON.stringify(payload));
          forkJoin(
            this.onBoardService.updateWorkflowTemplateDetails(
              onBoardDetailsID,
              workFlows
            ),
            this.onBoardService.updateScoreme(frmData)
          )
            .pipe(take(2))
            .subscribe(([res, data]) => {
              const payload = {
                profileId: this.onBoardService.profileId["profileID"],
                referId: data["data"]["referenceId"],
              };
              this.onBoardService
                .saveScoremeReport(payload)
                .subscribe((res) => {});
              this.selectedScoremeFile = "";
              Swal.fire({
                title: `<h3 class="swal-msg-font swal-title-font">${res.body["message"]}</h3>`,
                html: ``,
                showCancelButton: false,
                showConfirmButton: false,
                timer: 1500,
                focusConfirm: true,
                icon: "success",
              });
              if (res.body["message"] == "Approval is pending") {
                this._router.navigate(["/account/profile-loan-details"]);
              }
              this._router.navigate([
                "/on-board/" + this.onBoardService.workFlowID,
              ]);
            });
        } else {
          Swal.fire({
            title: `<h3 class="swal-msg-font swal-title-font">Statement file is required</h3>`,
            html: ``,
            showCancelButton: false,
            showConfirmButton: false,
            timer: 1500,
            focusConfirm: true,
            icon: "info",
          });
        }
      } else {
        let onBoardDetailsID = JSON.parse(this.onBoardService.onboardDetails);
        if (
          this.onBoardService.profileStatus.includes("Social Profiling") &&
          workFlows["Phone Number"] != this.cashFlowDetails["Phone Number"]
        ) {
          workFlows["Result"] = "";
        }
        if (
          !this.cashflowEmpty &&
          this.onBoardService.profileStatus.includes("Poverty Scorecard") &&
          !this.isEquivalent(workFlows, this.workflowClientDetails)
        ) {
          workFlows["Score Value"] = "";
        } else if (
          !this.cashflowEmpty &&
          this.onBoardService.profileStatus.includes("Risk score card") &&
          !this.isEquivalent(workFlows, this.workflowClientDetails)
        ) {
          workFlows["Score Value"] = "";
        }
        this.onBoardService
          .updateWorkflowTemplateDetails(onBoardDetailsID, workFlows)
          .subscribe((data) => {
            Swal.fire({
              title: "",
              text: data["message"],
              icon: "success",
            });
            if (data["message"] == "Approval is pending") {
              this._router.navigate(["/account/profile-loan-details"]);
            }
            if (
              this.onBoardService.profileStatus.includes("Social Profiling") &&
              !workFlows["Result"]
            ) {
              this.onBoardService.profileId;
              let payload = {
                customerID: this.profileDetails.profileID,
                from: "MFFVRF",
                to: workFlows["Phone Number"],
                name: this.profileDetails["Name"],
              };
              this.onBoardService
                .sendSocialLink(payload)
                .subscribe((res) => {});
            }
          });
      }
    } else {
    }
    if (this.imageFilesBundle) {
      this.imageFilesBundle.forEach((docs) => {
        const frmData = new FormData();
        docs.forEach(function (fileData, i) {
          frmData.append("files", fileData);
        });
        this._profileService.uploadFilesToProfile(
          this.onBoardService.profileId.ProfileId,
          "business",
          frmData
        );
      });
    }
  }

  isEquivalent(a, b) {
    var aProps = Object.getOwnPropertyNames(a);
    var bProps = Object.getOwnPropertyNames(b);
    if (aProps.length != bProps.length) {
      return false;
    }
    for (var i = 0; i < aProps.length; i++) {
      var propName = aProps[i];
      if (a[propName] !== b[propName]) {
        return false;
      }
    }
    return true;
  }
  selectedFile: any;
  labelName: any;
  fileUploaded = {};
  selectedScoremeFile: any;

  selFile(event, label) {
    this.selectedFile = null;
    this.selectedScoremeFile = null;
    let regex: RegExp = /[^\s]\.+(jpg|jpeg|png|pdf)$/i;
    if (regex.test(event.target.files[0].name)) {
      if (this.fileSize.getFileSize(event.target.files[0].size) < 501) {
        this.fileSizeExceeded = false;

        for (var key in event.target.files) {
          if (key !== "length" && key !== "item") {
            this.labelName = label;
            this.selectedFile = event.target.files[key];
            this.selectedScoremeFile = event.target.files[key];
          }
        }
      } else {
        this.fileSizeExceeded = true;
        Swal.fire({
          title: "File Size Exceeded",
          text: "Please Upload File Lesser Than 500 KB.",
          icon: "error",
        });
      }
    } else {
      Swal.fire({
        title: "",
        text: "Upload only JPG, JPEG, PDF, and PNG files",
        icon: "error",
      });
    }
  }

  selectFiles(event, label) {
    this.imageFiles = [];
    let regex: RegExp = /[^\s]\.+(jpg|jpeg|png|pdf)$/i;
    if (regex.test(event.target.files[0].name)) {
      if (this.fileSize.getFileSize(event.target.files[0].size) < 501) {
        this.fileSizeExceeded = false;

        for (var key in event.target.files) {
          if (key !== "length" && key !== "item") {
            this.imageFiles.push(event.target.files[key]);
          }
        }
        this.imageFilesBundle.push(this.imageFiles);
      } else {
        this.fileSizeExceeded = true;
        Swal.fire({
          title: "File Size Exceeded",
          text: "Please Upload File Lesser Than 500 KB.",
          icon: "error",
        });
      }
    } else {
      Swal.fire({
        title: "",
        text: "Upload only JPG, JPEG, PDF, and PNG files",
        icon: "error",
      });
    }
  }

  uploadFile(label) {
    const frmData = new FormData();
    if (this.selectedFile && this.labelName == label) {
      frmData.append(
        "files",
        this.selectedFile,
        label +
          "_" +
          this.today.split("T")[0] +
          " " +
          this.today.split("T")[1].split(".")[0] +
          "." +
          this.selectedFile.name.split(".")[1]
      );
      this._profileService
        .uploadFilesToProfile(
          this.onBoardService.profileId.profileID,
          "business",
          frmData
        )
        .subscribe((file) => {
          this.selectedFile = "";
          this.labelName = "";
          this.fileUploaded[label] = true;
          Swal.fire({
            title: "",
            text: "File uploaded",
            icon: "success",
          });
          // this._profileService
          //   .getFileList(this.onBoardService.profileId.profileID, "business")
          //   .subscribe((files) => {
          //     if (files.length > 0) {
          //       this.documents = files.map((file) => file.fileName);
          //       this.onBoardService.documents = this.documents;
          //       Swal.fire({
          //         title: "",
          //         text: "File uploaded",
          //         icon: "success",
          //       });
          //     }
          //   });
        });
    }
  }

  onVerify(workFlows: any) {
    if (JSON.stringify(workFlows) != "{}") {
      this.verifyObj["workflowTemplateDetails"][0]["workflowTemplateDetails"] =
        workFlows;
      delete this.verifyObj["workflowTemplateDetails"][0][
        "workflowTemplateDetails"
      ]["Status"];
      var errorCount = 0;
      if (
        this.onBoardService.profileStatus.includes("API-CreditBureau_CRIFHM")
      ) {
        for (const key in workFlows) {
          !workFlows[key] ? errorCount++ : "";
        }
        if (errorCount > 0) {
          Swal.fire({
            title: "",
            text: "Please fill all fields",
            icon: "warning",
          });
        } else {
          let onBoardDetailsID = JSON.parse(this.onBoardService.onboardDetails);
          this.onBoardService
            .verifyWorkflowTemplateDetails(this.verifyObj)
            .subscribe((data) => {
              this.onBoardService
                .updateWorkflowTemplateDetails(onBoardDetailsID, workFlows)
                .subscribe((data) => {
                  Swal.fire({
                    title: "",
                    text: data["message"],
                    icon: "success",
                  });

                  this._router.navigate([
                    "/on-board/" + this.onBoardService.workFlowID,
                  ]);
                });
            });
        }
      } else {
        let onBoardDetailsID = JSON.parse(this.onBoardService.onboardDetails);
        this.onBoardService
          .verifyWorkflowTemplateDetails(this.verifyObj)
          .subscribe((data) => {
            this.onBoardService
              .updateWorkflowTemplateDetails(onBoardDetailsID, workFlows)
              .subscribe((data) => {
                Swal.fire({
                  title: "",
                  text: data["message"],
                  icon: "success",
                });
                this._router.navigate([
                  "/on-board/" + this.onBoardService.workFlowID,
                ]);
              });
          });
        {
          this._router.navigate([
            "/on-board/" + this.onBoardService.workFlowID,
          ]);
        }
      }
    }
    if (this.imageFilesBundle) {
      this.imageFilesBundle.forEach((docs) => {
        const frmData = new FormData();
        docs.forEach(function (fileData, i) {
          frmData.append("files", fileData);
        });
        this._profileService.uploadFilesToProfile(
          this.onBoardService.profileId.ProfileId,
          "business",
          frmData
        );
      });
    }
  }

  maxLengthCheck(object) {
    if (object.target.value.length > Number(object.target.id)) {
      object.target.value = object.target.value.slice(
        0,
        object.target.maxLength
      );
    }
    if (Number(object.target.value) < 0) {
    } else {
    }
  }
  viewDocs() {
    this._router.navigate([
      "/document-storage/document-storage-profile/" +
        this.onBoardService.profileId.profileID,
    ]);
  }
  onBack() {
    this._router.navigate(["/on-board/" + this.onBoardService.workFlowID]);
  }
}
