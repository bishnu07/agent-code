import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KYCEditComponent } from './kyc-edit.component';

describe('EditProfileComponent', () => {
  let component: KYCEditComponent;
  let fixture: ComponentFixture<KYCEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KYCEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KYCEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
