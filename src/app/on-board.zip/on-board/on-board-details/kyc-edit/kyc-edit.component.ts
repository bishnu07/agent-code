import { Component, OnInit, ElementRef } from "@angular/core";
import { Router } from "@angular/router";
import { ApprovalService } from "../../../approval/approval.service";
import { ProfileService } from "../../../profiles/profile.service";
import { OnBoardService } from "../../on-board.service";
import { AppService } from "../../../app.service";
import { LoginService } from "app/shared/services/login.service";
import Swal from "sweetalert2";
import { Observable } from "rxjs";
import {
  NgbDateParserFormatter,
  NgbDateStruct,
} from "@ng-bootstrap/ng-bootstrap";
import { FileSizePipe } from "app/shared/pipes/filesize.pipe";

@Component({
  selector: "app-kyc-edit",
  templateUrl: "./kyc-edit.component.html",
  styleUrls: ["./kyc-edit.component.scss"],
})
export class KYCEditComponent implements OnInit {
  public Profileform: string;
  public editProfile = [];
  public profile = [];
  invalidDate;
  profileDetail;
  public profilelist = [];
  selectProfile = [];
  public profileId = "";
  profileformid: any;
  FormLabelValue: any;
  branchCodeList = [];
  ProvincesDetails = [];
  district = [];
  city = [];
  country = [];
  EconomicDetails = [];
  verifyDetails: any;
  fileSizeExceeded = false;
  showFileUpload = false;
  imageFiles = [];
  branches;
  groupData: any;
  groupShow = false;
  groupShow2 = false;
  item: any;
  selBranch;
  selGroup;
  branch = "";
  group = "";
  public AllowParentSelection = true;
  showBranch: boolean = false;
  branchID: any;
  hierarchyName: any;
  mapOfBranch: any;
  dropDownColumns = [];
  public dropDownColumnsFull = [];
  branchFilterString: any;
  public RestructureWhenChildSameName = false;
  public ShowFilter = true;
  public Disabled = false;
  public FilterPlaceholder = "";
  public MaxDisplayed = 500;
  documents = [];
  today = new Date().toISOString();
  show: boolean = false;
  pin_code: string;
  showNationalID: boolean = false;
  national_id: string;
  workflowData: any;
  workflowTemplates: any;
  public simpleSelected = {
    current_branch_id: "null",
  };
  map = new Map();
  EXCEL_TYPE =
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
  EXCEL_EXTENSION = ".xlsx";
  aadhaarID: number | boolean = true;
  aadhaarOtp: number | boolean = true;
  requestId = "";
  amlDate: any | boolean = true;
  amlName: number | boolean = true;
  selectedFile: any;

  constructor(
    private _service: ProfileService,
    public onboardService: OnBoardService,
    public ngbDateParserFormatter: NgbDateParserFormatter,
    private loginService: LoginService,
    private _router: Router,
    private approvalService: ApprovalService,
    private _onboardService: OnBoardService,
    public appService: AppService,
    private elementRef: ElementRef,
    private fileSize: FileSizePipe
  ) {}

  ngOnInit() {
    this.showFileUpload = true;
    this.editProfile = [];
    this.profilelist = [];
    this.mapOfBranch = this.loginService.map;
    this.verifyDetails = this._onboardService.verifyDetails;
    let formId = this._onboardService.profileId.hasOwnProperty("profileFormID")
      ? this._onboardService.profileId.profileFormID
      : this._onboardService.profileId.hasOwnProperty("FormID")
      ? this._onboardService.profileId.FormID
      : "";

    this._service.provideProfileFormById(formId).subscribe((data) => {
      let map = new Map();
      data["data"]["profileForm"]["profileFormDetails"]["Form Header"].forEach(
        (element) => {
          map.set(element["Label"], element["Value"]);
        }
      );
      this.FormLabelValue = map.get("Form Label");
      this.profilelist.push({
        formID: data["FormID"],
        formlabel: this.FormLabelValue,
      });
    });

    this._service.provideProfileFormByFormID(formId).subscribe((users) => {
      this.profileId = this._onboardService.profileId.profileID;
      let profileData =
        users["data"]["profileForm"]["profileFormDetails"]["Form Header"];
      users["data"]["profileForm"]["profileFormDetails"]["Form Body"].forEach(
        (element) => {
          profileData.push(element);
        }
      );
      this._service
        .provideProfileById(this._onboardService.profileId.profileID)
        .subscribe((users) => {
          this.profile = users["data"]["profiles"]["profileDetails"];
          this.profileDetail = users["data"]["profiles"];
          this.profile["Hierarchy"]
            ? (this.simpleSelected.current_branch_id =
                this.profile["Hierarchy"])
            : "";
          this.profile["Hierarchy"]
            ? (this.hierarchyName = this.mapOfBranch.get(
                this.profile["Hierarchy"]
              ))
            : "";
          this.profile["Hierarchy"]
            ? (this.branchID = this.profile["Hierarchy"])
            : "";
          if (
            profileData.filter((profs) => profs.Type == "Branch").length > 0
          ) {
            this._service
              .getBranches(
                profileData.filter((profs) => profs.Type == "Branch")[0].Value
              )
              .subscribe((branchData) => {
                this.branches = branchData;
              });
          }
          if (
            !this.profile["Age"] ||
            (this.profile["Date of Birth"] != "" && this.profile["Age"] == "")
          ) {
            this.profile["Age"] = this.getAge(this.profile["Date of Birth"]);
          }
          if (this.profile["Date of Birth"]) {
            let dob = { target: { value: "" } };
            dob["target"]["value"] = this.profile["Date of Birth"];
            this.dobChange(dob);
            this.profile["Date of Birth"] = this.parse(
              this.profile["Date of Birth"]
            );
          }
        });
      profileData.forEach((element1) => {
        if (element1.Type != "Branch") {
          this.editProfile.push(element1);
        }
      });
      this.editProfile.push(
        profileData.filter((prof) => prof.Type == "Branch")[0]
      );
    });
  }

  parse(value: string): NgbDateStruct {
    if (!value) return null;
    let parts = value.split("-");
    return {
      year: +parts[0],
      month: +parts[1],
      day: +parts[2],
    } as NgbDateStruct;
  }

  openAMLResult(form) {
    this.editProfile.forEach((el) => {
      if (el["Type"] == "Shuftipro-AMLI-DOB") {
        this.amlDate = form[el["Label"]] ? form[el["Label"]] : false;
      } else if (el["Type"] == "Shuftipro-AMLI-Name") {
        this.amlName = form[el["Label"]] ? form[el["Label"]] : false;
      }
    });
    if (this.amlDate && this.amlName) {
      let json = {
        reference: this.onboardService.profileId.profileID,
        background_checks: {
          name: {
            full_name: this.amlName,
          },
          dob: this.amlDate,
        },
      };
      this.onboardService.getAMLResult(json).subscribe(
        (res) => {
          let response = res["message"];
          for (const key in response) {
            response[key] == null ? (response[key] = "") : "";
          }
          Swal.fire({
            title: "",
            text: response["declined_reason"],
            icon: "success",
          });
          this.saveOtpTransaction(response, "AML");
          let onBoardDetailsID = JSON.parse(this.onboardService.onboardDetails);
          this.onboardService
            .updateWorkflowTemplateDetails(onBoardDetailsID, form)
            .subscribe((data) => {});
        },
        (error) => {
          let response = JSON.parse(error._body);
          this.saveOtpTransaction(response.message, "AML");
          Swal.fire({
            title: "Error",
            text: response.message["message"],
            icon: "error",
          });
        }
      );
    }
  }

  onAadharVerify(event) {
    this.aadhaarID = event ? event : false;
    if (typeof this.aadhaarID === "string") {
      let payload = {
        data: {
          customer_aadhaar_number: event,
          consent: "Y",
          consent_text:
            "I hear by declare my consent agreement for fetching my information via ZOOP API.",
        },
      };

      this.onboardService.verifyAadharID(payload).subscribe(
        (res) => {
          this.requestId = res.body.message["request_id"]
            ? res.body.message["request_id"]
            : "";
          Swal.fire({
            title: "",
            text: res.body.message["response_message"],
            icon: "success",
          });
        },
        (error) => {
          let errorMessage = JSON.parse(error._body);
          if (errorMessage.message) {
            let msg = errorMessage.message.hasOwnProperty("response_message")
              ? errorMessage.message["response_message"]
              : errorMessage.message.hasOwnProperty("response_message")
              ? errorMessage.message["response_message"]
              : errorMessage.message;
            Swal.fire({ title: "Sorry!", text: msg, icon: "warning" });
          }
          return Observable.throw(error || " server error ");
        }
      );
    }
  }

  onVerifyOTP(event) {
    this.aadhaarOtp = event ? true : false;
    if (
      this.aadhaarOtp &&
      this.requestId != "" &&
      this.requestId != undefined
    ) {
      let payload = {
        data: {
          request_id: this.requestId,
          otp: event,
          consent: "Y",
          consent_text:
            "I hear by declare my consent agreement for fetching my information via ZOOP API.",
        },
      };

      this.onboardService.verifyAadharOTP(payload).subscribe(
        (res) => {
          this.saveOtpTransaction(res.body["message"], "ZOOP");
          Swal.fire({
            title: "",
            text: res.body.message["response_message"],
            icon: "success",
          });
        },
        (error) => {
          let errorMessage = JSON.parse(error._body);
          this.saveOtpTransaction(errorMessage.message, "ZOOP");
          if (errorMessage.message) {
            let msg = errorMessage.message.hasOwnProperty("response_message")
              ? errorMessage.message["response_message"]
              : errorMessage.message.hasOwnProperty("response_message")
              ? errorMessage.message["response_message"]
              : errorMessage.message;
            Swal.fire({ title: "Sorry!", text: msg, icon: "warning" });
          }
        }
      );
    } else if (this.requestId != "" || this.requestId != undefined) {
      Swal.fire({
        title: "",
        text: "please verify aadhaar",
        icon: "warning",
      });
    }
  }

  saveOtpTransaction(jsonObject: any, fileName?: string) {
    this.saveAsJsonFile(jsonObject, "business");
    var frmData = new FormData();
    frmData.append(
      "files",
      this.selectedFile,
      fileName +
        "_" +
        this.today.split("T")[0] +
        " " +
        this.today.split("T")[1].split(".")[0] +
        "." +
        this.selectedFile.name.split(".")[1]
    );
    this._service
      .uploadFilesToProfile(
        this.onboardService.profileId.profileID,
        "business",
        frmData
      )
      .subscribe((file) => {
        this.selectedFile = "";
        this._service
          .getFileList(this.onboardService.profileId.profileID, "business")
          .subscribe((files) => {
            if (files) {
              this.documents = files.map((file) => file.fileName);
            }
          });
      });
  }

  private saveAsJsonFile(jsonObject: object, fileName: string) {
    this.EXCEL_TYPE = "application/json";
    const data: Blob = new Blob([JSON.stringify(jsonObject)], {
      type: this.EXCEL_TYPE,
    });
    let file = new File([data], "aadhaar.json");
    this.selectedFile = file;
  }

  dobChange(event) {
    var dateString = event.target.value;
    var myDate = new Date(dateString);
    var today = new Date();
    if (myDate > today) {
      this.invalidDate = true;
      this.profile["Age"] = 0;
    } else {
      this.invalidDate = false;
      this.profile["Age"] = this.getAge(event.target.value);
    }
  }

  getAge(dob) {
    let age;
    if (dob) {
      var timeDiff = Math.abs(Date.now() - new Date(dob).getTime());
      age = Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
      return age;
    } else return "";
  }

  selectFiles(event) {
    this.imageFiles = [];
    let regex: RegExp = /[^\s]\.+(jpg|jpeg|png|pdf)$/i;
    if (regex.test(event.target.files[0].name)) {
      if (this.fileSize.getFileSize(event.target.files[0].size) < 501) {
        this.fileSizeExceeded = false;

        for (var key in event.target.files) {
          if (key !== "length" && key !== "item") {
            this.imageFiles.push(event.target.files[key]);
          }
        }
      } else {
        this.imageFiles = [];
        this.fileSizeExceeded = true;
        Swal.fire({
          title: "File Size Exceeded",
          text: "Please Upload File Lesser Than 500 KB.",
          icon: "error",
        });
      }
    } else {
      this.imageFiles = [];
      Swal.fire({
        title: "",
        text: "Upload only JPG, JPEG, PDF, and PNG files",
        icon: "error",
      });
    }
  }

  onSubmit(profileDetails: any): void {
    if (this._onboardService.profileId) {
      this.branchID
        ? (profileDetails.Hierarchy = this.branchID)
        : (profileDetails.Hierarchy = "");
      for (const key in this.profile) {
        if (!(key in profileDetails)) profileDetails[key] = this.profile[key];
      }
      if (
        profileDetails.branchId == null ||
        profileDetails.branchId == "null"
      ) {
        profileDetails.branchId = "";
      }
      if (
        profileDetails.subBranchId == null ||
        profileDetails.subBranchId == "null" ||
        profileDetails.subBranchId == ""
      ) {
        delete profileDetails.subBranchId;
      }
      this.profileId = this._onboardService.profileId.profileID;
      profileDetails.profileFormID
        ? (profileDetails.FormID = profileDetails.profileFormID)
        : "";
      profileDetails.profileFormID ? delete profileDetails.profileFormID : "";
      this.editProfile.forEach((label) => {
        if (label.Type == "Date" || label.Type == "date") {
          profileDetails[label["Label"]] = new Date(
            this.ngbDateParserFormatter.format(profileDetails[label["Label"]])
          )
            .toISOString()
            .split("T")[0];
        }
      });

      this._service
        .updateProfile(JSON.stringify(profileDetails), this.profileId)
        .subscribe(
          (data) => {
            Swal.fire({
              title: ``,
              html: `<h5 class="swal-msg-font swal-text-font">${data["message"]}</h5>`,
              showConfirmButton: true,
              focusConfirm: true,
              confirmButtonColor: this.loginService.theme,
              confirmButtonText:
                '<span class=""  style="color:white;">Ok</span>',
              icon: "success",
            });
            this.verifyWorkflowTemplate(profileDetails);
            if (
              this.profileDetail.linkedProfileID &&
              this.profileDetail.linkedProfileID != "null"
            ) {
              this._service
                .provideProfileById(this.profileId)
                .subscribe((users) => {
                  let updateData = users["data"]["profiles"]["profileDetails"];
                  delete updateData.profilePicture;
                  delete updateData.FormID;
                  updateData.FormID = "1";
                  this._service
                    .updateProfileAsw(
                      updateData,
                      this.profileDetail.linkedProfileID
                    )
                    .subscribe((updateRes) => {});
                });
            }
            if (this.imageFiles.length > 0) {
              const frmData = new FormData();
              this.imageFiles.forEach((fileData) => {
                frmData.append("files", fileData);
              });
              this._service
                .uploadFilesToProfile(this.profileId, "personal", frmData)
                .subscribe();
            }
            this.ngOnInit();
          },
          (error) => {}
        );
    } else {
      Swal.fire({
        title: "No Profile Linked",
        text: "Please Link Profile",
        icon: "info",
      });
    }
  }

  selectChangeHandler(event: any) {
    this.selectProfile = event.target.value;
    this._service
      .provideProfileFormByFormID(event.target.value)
      .subscribe((data) => {
        let profileData = data["profileFormDetails"]["Form Body"];
        profileData.forEach((element1) => {
          this.editProfile.push(element1);
        });
      });
  }

  checkPincode(object) {
    this.pin_code = object.target.value;
    if (
      object.target.value.length > Number(object.target.id) ||
      object.target.value.length < Number(object.target.id)
    ) {
      this.show = true;
    } else if (object.target.value.length == Number(object.target.id)) {
      this.show = false;
    }
  }

  checkNationalID(object) {
    this.national_id = object.target.value;
    if (
      object.target.value.length > Number(object.target.id) ||
      object.target.value.length < Number(object.target.id)
    ) {
      this.showNationalID = true;
    } else if (object.target.value.length == Number(object.target.id)) {
      this.showNationalID = false;
    }
  }

  selectChangeHandlerState(event: any) {
    this._service.ProviceCityByStateID(event.target.value).subscribe((data) => {
      this.city = data;
    });
  }

  selectChangeHandlerDistrict(event: any) {}

  selectChangeHandlerCountry(event: any) {
    this._service
      .ProviceStateByCountryID(event.target.value)
      .subscribe((data) => {
        this.ProvincesDetails = data;
      });
  }

  onVerify() {
    this._onboardService
      .verifyWorkflowTemplateDetails(this._onboardService.verifyDetails)
      .subscribe((res) => {
        if (res["data"].hasOwnProperty("approved") && res["data"]["approved"]) {
          this._router.navigate(["/account/profile-loan-details"]);
        }
      });
  }

  verifyWorkflowTemplate(workflows) {
    let onBoardDetailsID = JSON.parse(this._onboardService.onboardDetails);
    this._onboardService
      .updateWorkflowTemplateDetails(onBoardDetailsID, workflows)
      .subscribe((data) => {
        this.isWorkflowApprovedAndVerified(data);
      });
  }

  isWorkflowApprovedAndVerified(data) {
    if (
      data["message"] === "Application is pending for approval" ||
      data["message"] === "Application is approved"
    ) {
      this._router.navigate(["/account/profile-loan-details"]);
    }
  }

  branchSelect(event) {
    let branGrp = this.branches.filter(
      (bran) => bran.current_branch_id == event.target.value
    )[0];
    this._service
      .getBranchGroup(branGrp.current_branch_id)
      .subscribe((grpData) => {
        if (JSON.stringify(grpData) != "[]") {
          this.groupData = grpData;
          this.groupShow = true;
        } else {
          this.groupShow = false;
          this.groupData = [];
        }
      });
  }

  viewDocs() {
    this._router.navigate([
      "/document-storage/document-storage-profile/" +
        this._onboardService.profileId.profileID,
    ]);
  }

  filterChk = "";
  filterBranch(name) {
    this.showBranch = true;
    let branchName: string = name;
    name.length < 4 ? (this.filterChk = "") : "";
    if (name.length > 3) {
      if (
        this.filterChk != "" &&
        name.includes(this.filterChk) &&
        this.dropDownColumnsFull.length != 0
      ) {
        this.branchFilterString = name;
        this.dropDownColumns = this.dropDownColumnsFull.filter((col) =>
          col.branch_name.toLowerCase().includes(name.toLowerCase())
        );
      } else {
        this.branchFilterString = name;
        this.dropDownColumns = [];
        this._service.searchBranchName(name).subscribe((res) => {
          this.dropDownColumns = res["data"]["portfolio"];
          this.dropDownColumnsFull = res["data"]["portfolio"];
        });
      }
      this.filterChk == "" ? (this.filterChk = name) : "";
    } else {
      this.dropDownColumns = [];
    }
  }

  branchDeselect(item: any, item1: any) {
    this.showBranch = false;
    this.branchID = item;
    this.hierarchyName = item1;
  }

  warning(alert) {
    Swal.fire({
      title: "Errors Found",
      text: "Please correct errors and submit",
      icon: "error",
    });
  }
  onBack() {
    this._router.navigate(["/on-board/" + this._onboardService.workFlowID]);
  }
}
