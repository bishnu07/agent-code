import {
  Component,
  OnInit,
  ViewChild,
  OnDestroy,
  AfterViewInit,
} from "@angular/core";

import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { LocalDataSource } from "ng2-smart-table";
import { Router, ActivatedRoute } from "@angular/router";
import { MatTableDataSource } from "@angular/material/table";
import { MatSort } from "@angular/material/sort";
import { MatStepper } from "@angular/material/stepper";
import { MatPaginator } from "@angular/material/paginator";

import { Location } from "@angular/common";
import { SelectionModel } from "@angular/cdk/collections";
import Swal from "sweetalert2";
import { map, take } from "rxjs/operators";

import { ApprovalService } from "../../approval/approval.service";
import { ProfileService } from "../../profiles/profile.service";
import { AppService } from "../../app.service";
import { LoginService } from "app/shared/services/login.service";
import { CashflowComponent } from "./cashflow/cashflow.component";
import {
  NgbModal,
  NgbDateParserFormatter,
  NgbDateStruct,
} from "@ng-bootstrap/ng-bootstrap";
import { Observable, forkJoin, Subscription } from "rxjs";
import { SafeResourceUrl, DomSanitizer } from "@angular/platform-browser";
import { AppComponent } from "app/app.component";
import { OnBoardService } from "../on-board.service";
import { FileSizePipe } from "app/shared/pipes/filesize.pipe";
import { HttpEventType } from "@angular/common/http";
import { ErrorDialogService } from "app/shared/services/error-dialog.service";

@Component({
  selector: "app-on-board-details",
  templateUrl: "./on-board-details.component.html",
  styleUrls: ["./on-board-details.component.scss"],
})
export class OnBoardDetailsComponent implements OnInit, OnDestroy {
  EXCEL_TYPE = "application/json";
  public amlName: string | boolean = true;
  public amlDate: string | boolean = true;
  aadhaarID: number | boolean = true;
  aadhaarOtp: number | boolean = true;
  requestId = "";
  today = new Date().toISOString();
  selectedFile;
  documents = [];
  dataSource: MatTableDataSource<any>;
  @ViewChild("stepper") stepper: MatStepper;
  workflowDescription: string;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  workFlowTempates = [];
  tableHeaders = [];
  tableDataDetails = [];
  tableDataDetails0 = [];
  tableDataDetails1 = [];
  tableDataDetails2 = [];
  AMLResponse: any;
  selectedData: any;
  loanVerify: boolean = false;
  bankVerify: boolean = false;
  kycVerify: boolean = false;
  API_CRIF: boolean = false;
  filterKyc: boolean = false;
  filterLoan: boolean = false;
  filterBank: boolean = false;
  filterCrif: boolean = false;
  displayedColumns = [];
  verificationTemplates = {};
  public show: boolean = true;
  public show1: boolean = false;
  public count: number = 0;
  smartTableLoadDataKYC = [];
  profiledetails = [];
  checked: boolean = true;
  indexDetailsData: any;
  detailsId: number = 0;
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thisRoute: string;
  KYC: LocalDataSource = new LocalDataSource();
  id: number;
  checkBoolean: boolean = false;
  tableDataStore = [];
  tableDataStoreFilter: any;
  checkedID: any;
  workflowName: any;
  linkedProfiles = [];
  private sub: Subscription;
  selectAll: boolean = false;
  printTable: any;
  selection = new SelectionModel(true, []);
  indx = 0;
  objectKeys = Object.keys;
  pageNo = 0;
  tableEnd: boolean = false;
  fromStepIndex: boolean = false;
  allBranches: any;
  index: number = 0;
  selectedItem: any;
  public items;
  public AllowParentSelection = true;
  public RestructureWhenChildSameName = false;
  public ShowFilter = true;
  public Disabled = false;
  public FilterPlaceholder = "";
  public MaxDisplayed = 10;
  public simpleSelected;
  branchNames = [];
  pageNoStepIndex0 = 0;
  pageNoStepIndex1 = 0;
  pageNoStepIndex2 = 0;
  pageNoStepIndex3 = 0;
  public map: any;
  public onboardDetailsData: any;
  stepPosition: number = 1;
  disableUpdate: boolean = false;
  hideApply: boolean = false;
  verifiedOrNot = "No";
  flowName;
  templateName = "";
  kycIndex;
  isLinked = false;
  approvalStage: boolean = false;
  shutiProUrl: SafeResourceUrl;
  private idVerification: Map<string, string> = new Map([
    ["National ID", "id_card"],
    ["Driving License", "driving_license"],
    ["Passport", "passport"],
  ]);
  templateVerified: boolean = false;
  workflowStatus = new Map<number, string>();
  templateStatus: string;

  constructor(
    private service: OnBoardService,
    private _formBuilder: FormBuilder,
    public sanitizer: DomSanitizer,
    private route: ActivatedRoute,
    private modalService: NgbModal,
    public ngbDateParserFormatter: NgbDateParserFormatter,
    private _router: Router,
    private _profileService: ProfileService,
    public appComponent: AppComponent,
    private appService: AppService,
    private locationvar: Location,
    private approvalService: ApprovalService,
    private loginService: LoginService,
    private cashFlowCom: CashflowComponent,
    private fileSize: FileSizePipe,
    private errorService: ErrorDialogService
  ) {}

  ngOnInit() {
    this.map = new Map();
    this.service.stepIndex = 0;
    this.cashFlowCom.stepPosition = 0;
    this.index = 0;
    this.pageNo = this.pageNo;
    this.service.linkProfileCount = 0;
    this._router.events.subscribe((val) => {
      if (this.locationvar.path() != "") {
        this.thisRoute = this.locationvar.path();
      } else {
        this.thisRoute = "Home";
      }
    });
    this.items = this.loginService.hierarchy;
    this.sub = this.route.params.subscribe((params) => {
      this.indx += 1;
      this.verificationTemplates["workflowTemplateDetails"] = [];
      this.checkBoolean = false;
      this.stepper.selectedIndex = this.service.stepIndex;
      this.id = params["id"];
      params["id"] ? (this.service.linkedProfiles = []) : "";
      if (this.id == this.service.workFlowID) {
        this.stepper.selectedIndex = this.service.stepIndex;
      } else {
        this.stepper.selectedIndex = 0;
      }
      this.service.workFlowID = this.id;
      this.map = this.loginService.map;
      this.tableDataStore = [];
      let pNo: string = JSON.stringify(this.pageNo);
      this.loginService.profile["details"]["profileID"];
      const filterData = {
        Identifier: this.loginService.profile["details"][0]["ClientID"],
        NationalID: this.loginService.profile["details"][0]["NationalID"],
      };
      this.workflowStatus = new Map();
      this.service
        .checkProfileLinkedToWorkflow(
          this.loginService.profileDetail["profileID"]
        )
        .subscribe((res) => {
          const check = res["data"]["workflow"].filter(
            (w) => w["workflowid"] == +this.id
          );
          if (check.length > 0 && check[0]["profilestatus"] != null) {
            this.templateStatus = check[0]["profilestatus"];
          } else {
            this.templateStatus = "";
          }
          this._profileService
            .provideProfilePagination(0, 10)
            .subscribe((users) => {
              let profileData =
                users["data"]["profiles"].length > 0
                  ? users["data"]["profiles"][0]["profileDetails"]
                  : [];
              this.service
                .getWorkflowTemplateDetails1(this.id, "No", pNo, 10, "")
                .subscribe((data1) => {
                  this.indexDetailsData = data1;
                  this.onboardDetailsData = data1;
                  this.workFlowTempates = [];
                  let datadetails = [];
                  datadetails.push(
                    [
                      {
                        Name: "Name-01",
                        "Last Name": "Last Name-01",
                        Gender: "MALE",
                        Address: "HYD",
                        Country: "INDIA",
                        Email: "mail@gmail.com",
                        Status: "draft",
                        Verification: "unverified",
                      },
                      {
                        Name: "Name-01",
                        "Last Name": "Last Name-01",
                        Gender: "MALE",
                        Address: "HYD",
                        Country: "INDIA",
                        Email: "mail@gmail.com",
                        Status: "Status-02",
                        Verification: "Verification-02",
                      },
                      {
                        Name: "Name-01",
                        "Last Name": "Last Name-01",
                        Gender: "MALE",
                        Address: "HYD",
                        Country: "INDIA",
                        Email: "mail@gmail.com",
                        Status: "Status-03",
                        Verification: "Verification-03",
                      },
                    ],
                    [
                      {
                        Name: "Name-01",
                        "Last Name": "Last Name-01",
                        Gender: "MALE",
                        Address: "HYD",
                        Country: "INDIA",
                        Email: "mail@gmail.com",
                        Income: "Income",
                        Expense: "Expense",
                        Assets: "Assets",
                        Liabilities: "Liabilities",
                        "Exposure percentage": "Exposure percentage",
                        "Loan Exposure": "Loan Exposure",
                      },
                    ],
                    [
                      {
                        Name: "Name-01",
                        "Last Name": "Last Name-01",
                        Gender: "MALE",
                        Address: "HYD",
                        Country: "INDIA",
                        Email: "mail@gmail.com",
                        "Credit Bureau Score": "Credit Bureau Score",
                        CIBIL: "CIBIL",
                      },
                    ],
                    [
                      {
                        Name: "Name-01",
                        "Last Name": "Last Name-01",
                        Gender: "MALE",
                        Address: "HYD",
                        Country: "INDIA",
                        Email: "mail@gmail.com",
                        "Credit Rating Score": "Credit Rating Score",
                        "Credit Rating Status": "Credit Rating Status",
                      },
                    ]
                  );
                  this.dataSource = new MatTableDataSource(datadetails[1]);
                  this.workFlowTempates.push(
                    { name: "KYC", Id: "1" },
                    { name: "KYC2", Id: "2" },
                    { name: "KYC3", Id: "3" },
                    { name: "KYC4", Id: "4" },
                    { name: "KYC5", Id: "5" }
                  );
                  this.dataSource.paginator = this.paginator;
                  this.dataSource.sort = this.sort;
                  let profileHeaders = [];
                  let index = 0;

                  this.service.getWorkflowByID(this.id).subscribe((temp) => {
                    this.workflowName =
                      temp["data"]["workflow"]["workFlowName"];
                    this.tableDataDetails = [];
                    this.count = 0;
                    this.service.workFlowName =
                      temp["data"]["workflow"]["workFlowName"];
                    this.workflowDescription = temp["data"]["workflow"][
                      "description"
                    ]
                      ? temp["data"]["workflow"]["description"]
                      : "";
                    this.workFlowTempates =
                      temp["data"]["workflow"]["workFlowTemplateDetails"];
                    let i = 0;
                    this.printTable = [];
                    let size = Object.keys(this.onboardDetailsData).length;
                    this.templateName = "";
                    if (size > 0) {
                      this.disableUpdate = true;
                      this.workFlowTempates.forEach((element) => {
                        if (i == 0) {
                          this.isLinked = true;
                          this.flowName = element["Label"]
                            ? element["Label"]
                            : "";
                          this.verifiedOrNot = this.onboardDetailsData[
                            element["Id"]
                          ]
                            ? this.onboardDetailsData[element["Id"]][0][
                                "Verified"
                              ]
                            : "Yes";
                          this.service.profileStatus = this.onboardDetailsData[
                            element["Id"]
                          ]
                            ? this.onboardDetailsData[element["Id"]][0][
                                "WorkflowTemplateCode"
                              ]
                            : "";
                          if (
                            this.templateStatus != "" &&
                            this.templateStatus.includes(
                              this.service.profileStatus
                            )
                          ) {
                            this.templateVerified = true;
                          } else {
                            this.templateVerified = false;
                          }
                          this.templateName = this.service.profileStatus
                            ? this.service.profileStatus == "KYC" ||
                              this.service.profileStatus == "Kyc" ||
                              this.service.profileStatus == "kyc"
                              ? this.service.profileStatus
                              : ""
                            : "";
                          if (this.verifiedOrNot == "No") {
                            this.service.profileId =
                              this.onboardDetailsData[element["Id"]][0];
                            this.loginService.profileData =
                              this.service.profileId;
                            this.onRowSelect(
                              this.onboardDetailsData[element["Id"]][0],
                              ""
                            );
                            this.kycIndex = this.templateName
                              ? this.service.stepIndex
                              : "";
                            this.hideApply = false;
                            let sel = this.service.profileId;
                            let objKeys = [
                              "Client ID",
                              "Name",
                              "WorkflowTemplateCode",
                            ];
                            let tabHeads = this.workFlowTempates.filter(
                              (wf) => wf.Id == sel.workflowTemplateId
                            )[0];
                            for (var key in tabHeads["Form Header"]) {
                              if (
                                key != "Label" &&
                                JSON.stringify(tabHeads["Form Header"][key]) !=
                                  "[]"
                              ) {
                                tabHeads["Form Header"][key].forEach(
                                  (heads) => {
                                    if (
                                      heads.Type != "Image" &&
                                      heads.Label != ""
                                    ) {
                                      objKeys.push(heads.Label);
                                    }
                                  }
                                );
                              }
                            }
                            let tabRow = {};
                            objKeys.forEach((keys) => {
                              if (keys != "Client ID") {
                                if (!sel[keys]) {
                                  let selData = sel["workflowTemplateDetails"];
                                  tabRow[keys] = selData[keys]
                                    ? selData[keys]
                                    : "";
                                } else if (sel[keys]) {
                                  tabRow[keys] = sel[keys] ? sel[keys] : "";
                                }
                              } else if (keys == "Client ID") {
                                tabRow[keys] = sel.Identifier;
                              }
                            });
                            this.printTable.push(tabRow);
                          } else {
                            this.hideApply = true;
                          }
                        }
                        i++;
                      });
                    } else {
                      this.service
                        .checkProfileLinked(filterData, this.id, 0, 10)
                        .subscribe((res) => {
                          if (JSON.stringify(res) == "{}") {
                            this.approvalStage = true;
                            this.isLinked = true;
                            this.swalInfoMsg(
                              "Profile Already Linked",
                              "Profile is on approval"
                            );
                          } else {
                            this.isLinked = false;
                          }
                        });
                    }
                  });
                });
            });
        });
      this.firstFormGroup = this._formBuilder.group({
        firstCtrl: ["", Validators.required],
      });
      this.secondFormGroup = this._formBuilder.group({
        secondCtrl: ["", Validators.required],
      });
    });
  }

  verifyIdentity(steps, group, modal) {
    let random = Math.floor(
      Math.random() * (999999999 - 100000000 + 1) + 10000000
    );
    let d = `${this.appService.redirect}/#/Pages/Verification`;
    if (group["ID Verification"] == "id_card") {
      let ref = "12457896565654"
        .concat(JSON.stringify(random))
        .concat(`_${this.service.profileId.profileID}`);
      d = d.concat(`?profileId=${this.service.profileId.profileID}`);
      d = d.concat(`&reference=${ref}`);
      d = d.concat(`&callUrl=${this.appService.mffURL}`);
      d = d.concat(`&idType=id_card`);
      let payload = {
        reference: ref,
        callback_url: this.appService.THIRD_PARTY_URL + "/callback/shufti",
        country: "IN",
        language: "EN",
        redirect_url: d,
        document: {
          supported_types: ["id_card"],
        },
        face: {},
      };

      this.service.getAMLResult(payload).subscribe((res) => {
        this.shutiProUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
          res["message"]["verification_url"]
        );
        this.modalService.open(modal);
      });
    } else if (group["ID Verification"] === "driving_license") {
      let ref = "521875654".concat(JSON.stringify(random));
      d = d.concat(`?profileId=${this.service.profileId.profileID}`);
      d = d.concat(`&reference=${ref}`);
      d = d.concat(`&callUrl=${this.appService.mffURL}`);
      d = d.concat(`&idType=driving_license`);
      let payload = {
        reference: ref,
        callback_url: this.appService.THIRD_PARTY_URL + "/callback/shufti",
        country: "IN",
        language: "EN",
        redirect_url: d,
        document: {
          supported_types: ["driving_license"],
        },
        face: {},
      };

      this.service.getAMLResult(payload).subscribe((res) => {
        this.shutiProUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
          res["message"]["verification_url"]
        );
        this.modalService.open(modal);
      });
    } else if (group["ID Verification"] === "passport") {
      let ref = "521875654".concat(JSON.stringify(random));
      d = d.concat(`?profileId=${this.service.profileId.profileID}`);
      d = d.concat(`&reference=${ref}`);
      d = d.concat(`&callUrl=${this.appService.mffURL}`);
      d = d.concat(`&idType=passport`);
      let payload = {
        reference: ref,
        callback_url: this.appService.THIRD_PARTY_URL + "/callback/shufti",
        country: "IN",
        language: "EN",
        redirect_url: d,
        document: {
          supported_types: ["passport"],
        },
        face: {},
      };

      this.service.getAMLResult(payload).subscribe((res) => {
        this.shutiProUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
          res["message"]["verification_url"]
        );
        this.modalService.open(modal);
      });
    }
  }

  private onSelectHandler(event: any, profileData) {
    let d = profileData.filter((p) => p.code == event.target.value)[0];
    this.service.fields.forEach((lb) => {
      if (lb.Label == d.dependency) {
        Object.assign(lb, { Value: d.children });
      }
    });
  }

  private isEmptyDescription(template): boolean {
    if (
      template["Form Header"].hasOwnProperty("Description") &&
      template["Form Header"]["Description"] != ""
    ) {
      return false;
    }
    return true;
  }

  getNestedBranches(obj, label) {
    this.branchNames.push(obj[label]);
    if (obj.children.length > 0) {
      obj.children.forEach((child) => {
        this.getNestedBranches(child, label);
      });
    }
  }

  applyFilter(filterValue: string) {
    this.tableDataDetails[this.service.stepIndex].filter = filterValue
      .trim()
      .toLowerCase();
    if (this.dataSource.paginator) {
    }
  }

  openPovertyResult(formDetails) {
    let onBoardDetailsID = JSON.parse(this.service.onboardDetails);
    this.service.getPovertyResult(onBoardDetailsID).subscribe((res) => {
      this.swalInfoMsg(`Score Value is ${res["scoreValue"]}`, "");
      this.cashFlowCom.cashFlowDetails["Score Value"] = res["scoreValue"];
      this.service
        .updateWorkflowTemplateDetails(onBoardDetailsID, formDetails)
        .subscribe((data) => {});
    });
  }

  onSubmit(workflows: any) {
    this.service.fields.forEach((label) => {
      if (label.Type == "Date" || label.Type == "date") {
        workflows[label["Label"]] = workflows[label["Label"]]
          ? new Date(
              this.ngbDateParserFormatter.format(workflows[label["Label"]])
            )
              .toISOString()
              .split("T")[0]
          : "";
      }
      if (
        label.Type == "Shuftipro-AMLI-DOB" &&
        workflows[label["Label"]] !== null
      ) {
        workflows[label["Label"]] = workflows[label["Label"]]
          ? this.parse(workflows[label["Label"]])
          : "";
      }
    });
    if (JSON.stringify(workflows) != "{}") {
      var errorCount = 0;
      if (
        this.service.profileStatus.includes("API-CreditBureau_CRIFHM") ||
        this.service.profileStatus.includes("CreditBureau_CRIFHM")
      ) {
        for (const key in workflows) {
          !workflows[key] ? errorCount++ : "";
        }
        if (errorCount > 0) {
          this.swalErrorMsg("", "Please fill all fields");
        } else {
          let onBoardDetailsID = JSON.parse(this.service.onboardDetails);
          this.service
            .updateWorkflowTemplateDetails(onBoardDetailsID, workflows)
            .subscribe((data) => {
              this.swalSuccessMsg("", data["message"]);
              this.isWorkflowApprovedAndVerified(data);
            });
        }
      } else if (this.service.profileStatus.includes("Bank Analyzer")) {
        let onBoardDetailsID = JSON.parse(this.service.onboardDetails);
        let frmData = new FormData();
        if (this.cashFlowCom.selectedScoremeFile) {
          const payload = {
            entityType: workflows["Entity Types"],
            bankCode: workflows["Bank Names"],
            accountType: workflows["Account Types"],
            accountNumber: workflows["Account Number"],
          };
          const label = "score_me";
          frmData.append(
            "file",
            this.cashFlowCom.selectedScoremeFile,
            label +
              "_" +
              this.today.split("T")[0] +
              " " +
              this.today.split("T")[1].split(".")[0] +
              "." +
              this.cashFlowCom.selectedScoremeFile.name.split(".")[1]
          );
          frmData.append("profileId", this.service.profileId["profileID"]);
          frmData.append(
            "workflowProfileId",
            this.service.profileId["workflowProfileID"]
          );
          frmData.append("accountDetails", JSON.stringify(payload));
          forkJoin(
            this.service.updateWorkflowTemplateDetails(
              onBoardDetailsID,
              workflows
            ),
            this.service.updateScoreme(frmData)
          )
            .pipe(take(2))
            .subscribe(([res, data]) => {
              this.cashFlowCom.selectedScoremeFile = "";
              this.swalSuccessMsg(res["message"], "");
              const payload = {
                profileId: this.service.profileId["profileID"],
                referId: data["data"]["referenceId"],
              };
              this.isWorkflowApprovedAndVerified(res);

              this.service.saveScoremeReport(payload).subscribe((res) => {});
            });
        } else {
          this.swalInfoMsg("Statement file is required", "");
        }
      } else {
        let onBoardDetailsID = JSON.parse(this.service.onboardDetails);
        if (
          this.service.profileStatus.includes("Social Profiling") &&
          workflows["Phone Number"] !=
            this.cashFlowCom.cashFlowDetails["Phone Number"]
        ) {
          workflows["Result"] = "";
        }
        if (
          !this.cashFlowCom.cashflowEmpty &&
          this.service.profileStatus.includes("Poverty Scorecard") &&
          !this.cashFlowCom.isEquivalent(
            workflows,
            this.cashFlowCom.workflowClientDetails
          )
        ) {
          workflows["Score Value"] = "";
        } else if (
          !this.cashFlowCom.cashflowEmpty &&
          this.service.profileStatus.includes("Risk score card") &&
          !this.cashFlowCom.isEquivalent(
            workflows,
            this.cashFlowCom.workflowClientDetails
          )
        ) {
          workflows["Score Value"] = "";
        }
        this.service
          .updateWorkflowTemplateDetails(onBoardDetailsID, workflows)
          .subscribe((data) => {
            this.swalSuccessMsg("", data["message"]);
            this.isWorkflowApprovedAndVerified(data);

            if (
              this.service.profileStatus.includes("Social Profiling") &&
              !workflows["Result"]
            ) {
              this.service.profileId;
              let payload = {
                customerID: this.cashFlowCom.profileDetails.profileID,
                from: "MFFVRF",
                to: workflows["Phone Number"],
                name: this.cashFlowCom.profileDetails["Name"],
              };
              this.service.sendSocialLink(payload).subscribe((res) => {});
            }
          });
      }
    } else {
    }
  }

  isWorkflowApprovedAndVerified(data) {
    if (
      data["message"] === "Application is pending for approval" ||
      data["message"] === "Application is approved"
    ) {
      this._router.navigate(["/account/profile-loan-details"]);
    }
  }

  parse(value: string): NgbDateStruct {
    if (!value) return null;
    let parts = value.split("-");
    return {
      year: +parts[0],
      month: +parts[1],
      day: +parts[2],
    } as NgbDateStruct;
  }

  onUpdate(workflows: any) {
    this.cashFlowCom.onSubmit(workflows);
  }

  openReport(modal) {
    this.cashFlowCom.openReport(modal);
  }

  printMeSocialProfiling() {
    const printContent = document.getElementById("neenerReport");
    const WindowPrt = window.open(
      "",
      "",
      "left=0,top=0,width=900,height=900,toolbar=0,scrollbars=0,status=0"
    );
    WindowPrt.document.write(printContent.innerHTML);
    WindowPrt.document.write(
      '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">'
    );
    WindowPrt.document.write(
      '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">'
    );
    WindowPrt.document.close();
    WindowPrt.focus();
    setTimeout(() => {
      WindowPrt.print();
    }, 500);
  }

  openSocialResult(modal, form) {
    this.cashFlowCom.openSocialResult(modal, form);
  }

  // uploadFile(label) {
  //   this.cashFlowCom.uploadFile(label);
  // }

  // selFile(event, label) {
  //   this.cashFlowCom.selFile(event, label);
  // }

  selectedScoremeFile: any;
  fileSizeExceeded = false;

  selFile(event, label) {
    this.selectedFile = null;
    this.selectedScoremeFile = null;
    let regex: RegExp = /[^\s]\.+(jpg|jpeg|png|pdf)$/i;
    if (regex.test(event.target.files[0].name)) {
      if (this.fileSize.getFileSize(event.target.files[0].size) < 501) {
        this.fileSizeExceeded = false;

        for (var key in event.target.files) {
          if (key !== "length" && key !== "item") {
            this.selectedFile = event.target.files[key];
            this.selectedScoremeFile = event.target.files[key];
          }
        }
      } else {
        this.fileSizeExceeded = true;
        Swal.fire({
          title: "File Size Exceeded",
          text: "Please Upload File Lesser Than 500 KB.",
          icon: "error",
        });
      }
    } else {
      Swal.fire({
        title: "",
        text: "Upload only JPG, JPEG, PDF, and PNG files",
        icon: "error",
      });
    }
  }

  uploadFile(label) {
    const frmData = new FormData();
    if (this.selectedFile) {
      frmData.append(
        "files",
        this.selectedFile,
        label +
          "_" +
          this.today.split("T")[0] +
          " " +
          this.today.split("T")[1].split(".")[0] +
          "." +
          this.selectedFile.name.split(".")[1]
      );

      this._profileService
        .uploadFilesToProfile(
          this.service.profileId.profileID,
          "business",
          frmData
        )
        .pipe(
          map((event: any) => {
            switch (event.type) {
              case HttpEventType.UploadProgress:
                break;
              case HttpEventType.Response: {
                this.errorService.sweetAlertConfirm(
                  "",
                  "Successfully uploaded",
                  "",
                  this.loginService.theme
                );
                return event;
              }
            }
          })
        )
        .subscribe(
          (event) => {},
          (error) => {
            this.selectedFile = null;
            this.selectedScoremeFile = null;
          }
        );
    }
  }

  viewDocs() {
    this.cashFlowCom.viewDocs();
  }

  printReport() {
    this.cashFlowCom.printReport();
  }

  linkProfile() {
    const profile = this.loginService.profile["details"];
    let inputData = {
      profileDetails: profile,
      workFlowID: this.service.workFlowID,
    };
    this.service.attachWorkflowToProfile(inputData).subscribe((data) => {
      console.log(data);
      if (data["message"] != "") {
        setTimeout(() => {
          this.swalSuccessMsg("", "Linked Successfully");
          this.ngOnInit();
        }, 2000);
      }
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  selIndex(event: any) {
    this.templateName = "";
    this.loginService.documentVerificationID = "";
    this.workFlowTempates.forEach((element) => {
      if (event.selectedIndex != 0) {
        this.hideApply = true;
      } else {
        this.hideApply = false;
      }
    });

    this.service.stepIndex = event.selectedIndex;
    this.verificationTemplates["workflowTemplateDetails"] = [];
    this.printTable = [];
    this.checkBoolean = false;
    this.selection.clear();
    this.pageNo =
      this.service.stepIndex == 0
        ? this.pageNoStepIndex0
        : this.service.stepIndex == 1
        ? this.pageNoStepIndex1
        : this.service.stepIndex == 2
        ? this.pageNoStepIndex2
        : this.service.stepIndex == 3
        ? this.pageNoStepIndex3
        : 0;
    let i = 0;
    let size = this.isEmpty(this.onboardDetailsData);
    this.workFlowTempates.forEach((element) => {
      if (event.selectedIndex == i) {
        this.verifiedOrNot = this.onboardDetailsData[element["Id"]]
          ? this.onboardDetailsData[element["Id"]][0]["Verified"]
          : "Yes";
        this.flowName = element["Label"] ? element["Label"] : "";
        this.service.profileStatus = this.onboardDetailsData[element["Id"]]
          ? this.onboardDetailsData[element["Id"]][0]["WorkflowTemplateCode"]
          : "";
        this.templateName = this.service.profileStatus
          ? this.service.profileStatus == "KYC" ||
            this.service.profileStatus == "Kyc" ||
            this.service.profileStatus == "kyc"
            ? this.service.profileStatus
            : ""
          : "";
        this.kycIndex = this.templateName ? this.service.stepIndex : "";
        if (
          this.templateStatus != "" &&
          this.templateStatus.includes(this.service.profileStatus)
        ) {
          this.templateVerified = true;
        } else {
          this.templateVerified = false;
        }
        if (this.verifiedOrNot == "No") {
          this.service.profileId = this.onboardDetailsData[element["Id"]][0];
          this.loginService.profileData = this.service.profileId;
          this.onRowSelect(this.onboardDetailsData[element["Id"]][0], "");
          this.printTable = [];
          let sel = this.service.profileId;
          let objKeys = ["Client ID", "Name", "WorkflowTemplateCode"];
          let tabHeads = this.workFlowTempates.filter(
            (wf) => wf.Id == sel.workflowTemplateId
          )[0];
          for (var key in tabHeads["Form Header"]) {
            if (
              key != "Label" &&
              JSON.stringify(tabHeads["Form Header"][key]) != "[]"
            ) {
              tabHeads["Form Header"][key].forEach((heads) => {
                if (heads.Type != "Image" && heads.Label != "") {
                  objKeys.push(heads.Label);
                }
              });
            }
          }
          let tabRow = {};
          objKeys.forEach((keys) => {
            if (keys != "Client ID") {
              if (!sel[keys]) {
                let selData = sel["workflowTemplateDetails"];
                tabRow[keys] = selData[keys] ? selData[keys] : "";
              } else if (sel[keys]) {
                tabRow[keys] = sel[keys] ? sel[keys] : "";
              }
            } else if (keys == "Client ID") {
              tabRow[keys] = sel.Identifier;
            }
          });
          this.printTable.push(tabRow);
        } else {
          this.cashFlowCom.stepPosition = 0;
          this.hideApply = true;
        }
      }
      i++;
    });
  }

  onVerify() {
    this.verificationTemplates["workflowTemplateDetails"] = [];
    let selectedTemplate;
    var itemsProcessed = 0;
    if (this.selection.selected.length > 0) {
      this.selection.selected.forEach((sel, index, array) => {
        this.service.getTemplateID(sel["detailsID"]).subscribe((data) => {
          selectedTemplate = data;
          for (var key in selectedTemplate) {
            if (key !== "templateDetailsID") {
              if (key !== "templateID") {
                if (key !== "workflowProfileID") {
                  if (key !== "workflowTemplateDetails") {
                    delete selectedTemplate[key];
                  }
                }
              }
            }
          }
          this.verificationTemplates["workflowTemplateDetails"].push(
            selectedTemplate
          );
          itemsProcessed++;
          if (itemsProcessed === array.length) {
            this.service
              .verifyWorkflowTemplateDetails(this.verificationTemplates)
              .subscribe((data) => {
                this.selection.clear();
                if (this.service.stepIndex == 0) {
                  this.loanVerify = true;
                } else if ((this.service.stepIndex = 1)) {
                  this.bankVerify = true;
                } else if ((this.service.stepIndex = 2)) {
                  this.API_CRIF = true;
                }
                this.ngOnInit();
              });
          }
        });
      });
    } else {
      this.swalWarningMsg(
        "No Client Selected",
        "Please select a client to verify"
      );
    }
  }

  onRowSelect(event: any, idx: any) {
    this.service.onboardDetails = JSON.stringify(event.detailsID);
    this.service.profileStatus = event.WorkflowTemplateCode;
    let profilePayload = {};
    let verifyPayload = {};
    verifyPayload["workflowTemplateDetails"] = [];
    let selectedTemplate = {};
    if (event.WorkflowTemplateCode.includes("KYC")) {
      this.cashFlowCom.stepPosition = 0;
      profilePayload["profileFormID"] = event.profileFormID || event.FormID;
      profilePayload["profileID"] = event.profileID;
      profilePayload["verify"] = true;
      let detailId = JSON.parse(event.detailsID);

      this.service.getTemplateID(detailId).subscribe((data) => {
        selectedTemplate = data;
        for (var key in selectedTemplate) {
          if (key !== "templateDetailsID") {
            if (key !== "templateID") {
              if (key !== "workflowProfileID") {
                if (key !== "workflowTemplateDetails") {
                  delete selectedTemplate[key];
                }
              }
            }
          }
        }
        verifyPayload["workflowTemplateDetails"].push(selectedTemplate);
        this.service.verifyDetails = verifyPayload;
        this.service.profileId = profilePayload;
        this.loginService.profileData = this.service.profileId;
        this.stepPosition = 0;
      });
    } else {
      this.service.profileId = event;
      this.loginService.profileData = this.service.profileId;
      this.stepPosition = 1;
      this.cashFlowCom.ngOnInit();
    }
  }

  ApproveProfile(event: any) {
    this.service
      .approveProfiles(this.service.onboardDetails)
      .subscribe((data) => {
        this._router.navigate(["Approval/Approval"]);
      });
  }

  get AMLResult() {
    return JSON.stringify(this.AMLResponse);
  }

  onAadharVerify(event) {
    this.aadhaarID = event ? event : false;
    if (typeof this.aadhaarID === "string") {
      let payload = {
        data: {
          customer_aadhaar_number: event,
          consent: "Y",
          consent_text:
            "I hear by declare my consent agreement for fetching my information via ZOOP API.",
        },
      };
      this.service.verifyAadharID(payload).subscribe(
        (res) => {
          this.requestId = res.body.message["request_id"]
            ? res.body.message["request_id"]
            : "";
          this.swalSuccessMsg("", res.body.message["response_message"]);
        },
        (error) => {
          let errorMessage = JSON.parse(error._body);
          if (errorMessage.message) {
            let msg = errorMessage.message.hasOwnProperty("response_message")
              ? errorMessage.message["response_message"]
              : errorMessage.message.hasOwnProperty("response_message")
              ? errorMessage.message["response_message"]
              : errorMessage.message;
            this.swalWarningMsg("Sorry!", msg);
          }
          return Observable.throw(error || " server error ");
        }
      );
    }
  }

  onVerifyOTP(event) {
    this.aadhaarOtp = event ? true : false;
    if (
      this.aadhaarOtp &&
      this.requestId != "" &&
      this.requestId != undefined
    ) {
      let payload = {
        data: {
          request_id: this.requestId,
          otp: event,
          consent: "Y",
          consent_text:
            "I hear by declare my consent agreement for fetching my information via ZOOP API.",
        },
      };
      this.service.verifyAadharOTP(payload).subscribe(
        (res) => {
          this.saveOtpTransaction(res.body["message"], "ZOOP");
          this.swalSuccessMsg("", res.body.message["response_message"]);
        },
        (error) => {
          let errorMessage = JSON.parse(error._body);
          this.saveOtpTransaction(errorMessage.message, "ZOOP");
          if (errorMessage.message) {
            let msg = errorMessage.message.hasOwnProperty("response_message")
              ? errorMessage.message["response_message"]
              : errorMessage.message.hasOwnProperty("response_message")
              ? errorMessage.message["response_message"]
              : errorMessage.message;
            this.swalWarningMsg("Sorry!", msg);
          }
        }
      );
    } else if (this.requestId != "" || this.requestId != undefined) {
      this.swalWarningMsg("", "Please verify aadhaar");
    }
  }

  openAMLResult(form) {
    this.service.fields.forEach((el) => {
      if (el["Type"] == "Shuftipro-AMLI-DOB") {
        this.amlDate = form[el["Label"]]
          ? new Date(this.ngbDateParserFormatter.format(form[el["Label"]]))
              .toISOString()
              .split("T")[0]
          : false;
      } else if (el["Type"] == "Shuftipro-AMLI-Name") {
        this.amlName = form[el["Label"]] ? form[el["Label"]] : false;
      }
    });
    if (this.amlDate && this.amlName) {
      let json = {
        reference: this.service.profileId.profileID,
        background_checks: {
          name: {
            full_name: this.amlName,
          },
          dob: this.amlDate,
        },
      };
      this.service.getAMLResult(json).subscribe(
        (res) => {
          let response = res.message;
          for (const key in response) {
            response[key] == null ? (response[key] = "") : "";
          }
          this.swalSuccessMsg("", response["declined_reason"]);
          this.saveOtpTransaction(response, "AML");
          let onBoardDetailsID = JSON.parse(this.service.onboardDetails);
          this.service
            .updateWorkflowTemplateDetails(onBoardDetailsID, form)
            .subscribe((data) => {});
        },
        (error) => {
          let response = JSON.parse(error._body);
          this.saveOtpTransaction(response.message, "AML");
          this.swalErrorMsg("Error", response.message["message"]);
        }
      );
    }
  }

  saveOtpTransaction(jsonObject: any, fileName?: string) {
    this.saveAsJsonFile(jsonObject, "business");
    var frmData = new FormData();
    frmData.append(
      "files",
      this.selectedFile,
      fileName +
        "_" +
        this.today.split("T")[0] +
        " " +
        this.today.split("T")[1].split(".")[0] +
        "." +
        this.selectedFile.name.split(".")[1]
    );
    this._profileService
      .uploadFilesToProfile(
        this.service.profileId.profileID,
        "business",
        frmData
      )
      .subscribe((file) => {
        this.selectedFile = "";
        this._profileService
          .getFileList(this.service.profileId.profileID, "business")
          .subscribe((files) => {
            if (files) {
              this.service.documents = files.map((file) => file.fileName);
            }
          });
      });
  }

  getDocuments() {
    this._profileService
      .getFileList(this.service.profileId.profileID, "business")
      .subscribe((files) => {
        if (files) {
          this.service.documents = files.map((file) => file.fileName);
        }
      });
  }

  private saveAsJsonFile(jsonObject: object, fileName: string) {
    const data: Blob = new Blob([JSON.stringify(jsonObject)], {
      type: this.EXCEL_TYPE,
    });
    let file = new File([data], "aadhaar.json");
    this.selectedFile = file;
  }

  printAML() {
    const printContent = document.getElementById("AMLPrint");
    const WindowPrt = window.open(
      "",
      "",
      "left=0,top=0,width=900,height=150,toolbar=0,scrollbars=0,status=0"
    );
    WindowPrt.document.write(printContent.innerHTML);
    WindowPrt.document.write(
      '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">'
    );
    WindowPrt.document.write(
      '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">'
    );
    WindowPrt.document.close();
    WindowPrt.focus();
    setTimeout(() => {
      WindowPrt.print();
    }, 500);
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    this.selectedData = this.selection.selected;
    const numRows = this.tableDataDetails[this.service.stepIndex].data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected()
      ? this.selection.clear()
      : this.tableDataDetails[this.service.stepIndex].data.forEach((row) =>
          this.selection.select(row)
        );
  }

  checkboxToggle() {
    this.printTable = [];
    let i = 0;
    this.workFlowTempates.forEach((element) => {
      if (this.service.stepIndex == i) {
        this.selection.selected.forEach((sel) => {
          let data = this.onboardDetailsData[element["id"]];
          let objKeys = ["Client ID", "Name", "WorkflowTemplateCode"];
          let tabHeads = this.workFlowTempates.filter(
            (wf) => wf.Id == data.workflowTemplateId
          )[0];
          for (var key in tabHeads["Form Header"]) {
            if (
              key != "Label" &&
              JSON.stringify(tabHeads["Form Header"][key]) != "[]"
            ) {
              tabHeads["Form Header"][key].forEach((heads) => {
                if (heads.Type != "Image" && heads.Label != "") {
                  objKeys.push(heads.Label);
                }
              });
            }
          }
          let tabRow = {};
          objKeys.forEach((keys) => {
            if (keys != "Client ID") {
              if (!sel[keys]) {
                let selData = sel["workflowTemplateDetails"];
                tabRow[keys] = selData[keys] ? selData[keys] : "";
              } else if (sel[keys]) {
                tabRow[keys] = sel[keys] ? sel[keys] : "";
              }
            } else if (keys == "Client ID") {
              tabRow[keys] = sel.Identifier;
            }
          });
          this.printTable.push(tabRow);
        });
      }
      i++;
    });
  }

  swalSuccessMsg(title?: string, text?: string) {
    Swal.fire({
      title: `<h3 class="swal-msg-font swal-title-font">${title}</h3>`,
      html: `<h5 class="swal-msg-font swal-title-font">${text}</h5>`,
      showConfirmButton: true,
      focusConfirm: true,
      confirmButtonColor: this.appService.themeColor,
      confirmButtonText: '<span class="" style="color:white;">Ok</span>',
      icon: "success",
    });
  }

  swalErrorMsg(title?: string, text?: string) {
    Swal.fire({
      title: `<h3 class="swal-msg-font swal-title-font">${title}</h3>`,
      html: `<h5 class="swal-msg-font swal-title-font">${text}</h5>`,
      showConfirmButton: true,
      focusConfirm: true,
      confirmButtonColor: this.appService.themeColor,
      confirmButtonText: '<span class="" style="color:white;">Ok</span>',
      icon: "error",
    });
  }

  swalWarningMsg(title?: string, text?: string) {
    Swal.fire({
      title: `<h3 class="swal-msg-font swal-title-font">${title}</h3>`,
      html: `<h5 class="swal-msg-font swal-title-font">${text}</h5>`,
      showConfirmButton: true,
      focusConfirm: true,
      confirmButtonColor: this.appService.themeColor,
      confirmButtonText: '<span class="" style="color:white;">Ok</span>',
      icon: "warning",
    });
  }

  swalInfoMsg(title?: string, text?: string) {
    Swal.fire({
      title: `<h3 class="swal-msg-font swal-title-font">${title}</h3>`,
      html: `<h5 class="swal-msg-font swal-title-font">${text}</h5>`,
      showConfirmButton: true,
      focusConfirm: true,
      confirmButtonColor: this.appService.themeColor,
      confirmButtonText: '<span class="" style="color:white;">Ok</span>',
      icon: "info",
    });
  }

  printMe() {
    if (!this.isEmpty(this.onboardDetailsData)) {
      const printContent = document.getElementById("workflowPrint");
      const WindowPrt = window.open(
        "",
        "",
        "left=0,top=0,width=900,height=900,toolbar=0,scrollbars=0,status=0"
      );
      WindowPrt.document.write(printContent.innerHTML);
      WindowPrt.document.write(
        '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">'
      );
      WindowPrt.document.close();
      setTimeout(() => {
        WindowPrt.print();
      }, 500);
    } else {
      this.isLinked = false;
    }
  }

  isEmpty(obj) {
    for (var key in obj) {
      if (obj.hasOwnProperty(key)) return false;
    }
    return true;
  }
}
