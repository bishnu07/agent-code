import { Component, OnInit } from "@angular/core";
import { OnBoardService } from "../../on-board.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-credit-bureau",
  templateUrl: "./credit-bureau.component.html",
  styleUrls: ["./credit-bureau.component.scss"],
})
export class CreditBureauComponent implements OnInit {
  fileds: any = [];
  creditBureauData: any = {};
  data: any;
  cashFlowPPI = [];
  cashFlowTemp = [];
  CreditBureauScore: any;
  CIBIL: any;

  constructor(
    private onBoardService: OnBoardService,
    private _router: Router
  ) {}

  ngOnInit() {
    this.data = this.onBoardService.profileStatus.WorkflowTemplateCode;
    this.onBoardService
      .getWorkflowTemplateDetailsByID(
        this.onBoardService.creditBureauData.detailsID
      )
      .subscribe((data) => {
        this.onBoardService
          .getWorkflowTemplatesByID(data["templateID"])
          .subscribe((temp) => {
            temp["workFlowTemplates"]["Form Body"].forEach((element) => {
              this.cashFlowPPI.push(element);
            });
            temp["workFlowTemplates"]["Fileds"].forEach((element) => {
              this.cashFlowTemp.push(element);
            });
          });
        this.CreditBureauScore =
          data["workflowTemplateDetails"]["Credit Bureau Score"];
        this.CIBIL = data["workflowTemplateDetails"]["CIBIL"];
        this.creditBureauData = data["workflowTemplateDetails"];
        for (let prop in data["workflowTemplateDetails"]) {
          this.fileds.push(prop);
        }
      });
  }

  onSubmit(workFlows: any) {
    this.onBoardService
      .updateWorkflowTemplateDetails(
        this.onBoardService.creditBureauData.detailsID,
        workFlows
      )
      .subscribe((data) => {
        this._router.navigate(["/on-board/" + this.onBoardService.workFlowID]);
      });
  }
}
