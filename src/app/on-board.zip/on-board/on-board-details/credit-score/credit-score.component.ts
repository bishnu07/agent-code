import { Component, OnInit } from "@angular/core";
import { OnBoardService } from "../../on-board.service";
import { Router, ActivatedRoute } from "@angular/router";

@Component({
  selector: "app-credit-score",
  templateUrl: "./credit-score.component.html",
  styleUrls: ["./credit-score.component.scss"],
})
export class CreditScoreComponent implements OnInit {
  fileds: any = [];
  creditScoreData: any = {};
  data: any;
  constructor(
    private onBoardService: OnBoardService,
    private _router: Router
  ) {}

  ngOnInit() {
    this.data = this.onBoardService.profileStatus.WorkflowTemplateCode;
    this.onBoardService
      .getWorkflowTemplateDetailsByID(
        this.onBoardService.creditScoreData.detailsID
      )
      .subscribe((data) => {
        this.creditScoreData = data["workflowTemplateDetails"];
        for (let prop in data["workflowTemplateDetails"]) {
          this.fileds.push(prop);
        }
      });
  }
  onSubmit(workFlows: any) {
    this.onBoardService
      .updateWorkflowTemplateDetails(
        this.onBoardService.creditScoreData.detailsID,
        JSON.stringify(workFlows)
      )
      .subscribe((data) => {
        this._router.navigate(["/on-board/" + this.onBoardService.workFlowID]);
      });
  }
}
