import { PipeTransform, Pipe } from '@angular/core';
@Pipe({ name: 'camelcase' })
export class CamelcasePipe implements PipeTransform {
  transform(value, args: string[]): any {

    var inputString = value.charAt(0).toUpperCase() + value.slice(1)
    return inputString.match(/[A-Z][a-z]+|[0-9]+/g).join(" ");
  }
}