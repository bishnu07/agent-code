import { ErrorDialogService } from "../../shared/services/error-dialog.service";

import { FileSizePipe } from "../../shared/pipes/filesize.pipe";

import { Component, OnInit, OnDestroy } from "@angular/core";

import { ProfileService } from "../profile.service";

import { AppService } from "../../app.service";

import { DomSanitizer } from "@angular/platform-browser";

import { LoginService } from "app/shared/services/login.service";

import {
  NgbDateParserFormatter,
  NgbDateStruct,
} from "@ng-bootstrap/ng-bootstrap";

import { AppComponent } from "app/app.component";

import { EMPTY, Subject, Subscription, of } from "rxjs";

import {
  catchError,
  map,
  mergeMap,
  switchMap,
  take,
  tap,
} from "rxjs/operators";

import { HttpEventType } from "@angular/common/http";

interface ParseDate {
  year: string;
  month: string;
  day: string;
}

@Component({
  selector: "app-edit-profile",
  templateUrl: "./edit-profile.component.html",
  styleUrls: ["./edit-profile.component.scss"],
})
export class EditProfileComponent implements OnInit, OnDestroy {
  items: any;

  profileForm: any;

  profile: any[] = [];

  showFileUpload: boolean = false;

  profPhoto: string;

  filePreview: string;

  imgUrl: any;

  branchID: any;

  showBranch: boolean = false;

  hierarchyName: string;

  mapOfBranch = new Map();

  simpleSelected = {
    current_branch_id: "null",
  };

  filePreviewAvailable: boolean = false;

  private profileUpdateSubject$ = new Subject<any>();

  private destroy$ = new Subject<void>();

  private subscription: Subscription[] = [];

  filterChk: string = "";

  dropDownColumns = [];

  dropDownColumnsFull = [];

  defaultImageUrlPath = "/assets/img/user2.png";

  documentFileSize: string;

  profilePictureFileSize: string;

  progress: number;

  progressProfilePicture: number;

  documentFile: any;

  fileSizeExceeded: boolean = false;

  photoSizeExceeded: boolean = false;

  constructor(
    private _service: ProfileService,
    private ngbDateParserFormatter: NgbDateParserFormatter,
    private appComponent: AppComponent,
    private sanitizer: DomSanitizer,
    private appService: AppService,
    private loginService: LoginService,
    private fileSize: FileSizePipe,
    private errorService: ErrorDialogService
  ) {
    $(document).ready(() => {
      this.loginService.changeTableTheme();
    });
  }

  ngOnInit() {
    const profileId = this.loginService.profile["details"][0]["profileID"];
    this.updateProfile(profileId);
    this.init(profileId);
  }

  init(profileId: string) {
    this.showFileUpload = true;

    this.mapOfBranch = this.loginService.map;

    this._service
      .provideProfileById(profileId)
      .pipe(
        tap((user) => {
          this.profile = user["data"]["profiles"]["profileDetails"];

          this.loginService.profileDetail = user["data"]["profiles"];

          this.profile["Hierarchy"]
            ? (this.branchID = this.profile["Hierarchy"])
            : "";

          this.profile["Hierarchy"]
            ? (this.simpleSelected.current_branch_id =
                this.profile["Hierarchy"])
            : "";

          this.profile["Hierarchy"]
            ? (this.hierarchyName = this.mapOfBranch.get(
                this.profile["Hierarchy"]
              ))
            : "";

          if (this.profile["profilePicture"]) {
            this.filePreview = "";

            this.filePreviewAvailable = true;

            this.imgUrl =
              this.profile["profilePicture"] +
              "?access_token=" +
              this._service.access_token;
          }
          this.profPhoto = this.profile["Photo"];
        }),

        switchMap((user) => {
          // get profile form by form Id.
          return this._service.provideProfileFormByFormID(
            user["data"]["profiles"]["profileFormID"]
          );
        }),

        take(1)
      )
      .subscribe((profForm) => {
        let profileData =
          profForm["data"]["profileForm"]["profileFormDetails"]["Form Header"];

        profForm["data"]["profileForm"]["profileFormDetails"][
          "Form Body"
        ].forEach((element) => {
          if (element.Type == "Date") {
            this.profile[element["Label"]] = this.parse(
              this.profile[element["Label"]]
            );
          }
          profileData.push(element);
        });

        if (profileData.filter((profs) => profs.Type == "Branch").length == 0) {
          this.profileForm = profileData;
        } else {
          let branchForm = profileData.filter(
            (profs) => profs.Type == "Branch"
          )[0];
          profileData.splice(
            profileData.findIndex(function (i) {
              return i.Type === "Branch";
            }),
            1
          );
          profileData.push(branchForm);
          this.profileForm = profileData;
        }

        this.profileForm = profileData;

        console.log(this.profileForm);
      });
  }

  updateProfile(profileId: string): void {
    this.profileUpdateSubject$
      .pipe(
        switchMap((profileDetails: any) => {
          this.branchID
            ? (profileDetails.Hierarchy = this.branchID)
            : (profileDetails.Hierarchy = "");
          for (const key in this.profile) {
            if (!(key in profileDetails) && key != "Age") {
              profileDetails[key] = this.profile[key];
            } else if (key == "Age" && this.profile[key]) {
              profileDetails[key] = this.profile[key];
            }
          }
          profileDetails.profileFormID
            ? (profileDetails.FormID = profileDetails.profileFormID)
            : "";
          profileDetails.profileFormID
            ? delete profileDetails.profileFormID
            : "";

          this.profileForm.forEach((label) => {
            if (label.Type == "Date" || label.Type == "date") {
              if (
                this.ngbDateParserFormatter.format(
                  profileDetails[label["Label"]]
                ) != "undefined--"
              ) {
                //changing date format to dd-mm-yyyy
                profileDetails[label["Label"]] = profileDetails[label["Label"]]
                  ? new Date(
                      this.ngbDateParserFormatter.format(
                        profileDetails[label["Label"]]
                      )
                    )
                      .toISOString()
                      .split("T")[0]
                  : "";
              }
            }
          });

          return this._service
            .updateProfile(JSON.stringify(profileDetails), profileId)
            .pipe(catchError(() => EMPTY));
        }),

        switchMap(() => {
          if (
            this.loginService.profileDetail.linkedProfileID &&
            this.loginService.profileDetail.linkedProfileID != "null"
          ) {
            return this._service.provideProfileById(profileId).pipe(
              mergeMap((users) => {
                let updateData = users["data"]["profiles"]["profileDetails"];
                delete updateData.profilePicture;
                delete updateData.FormID;
                updateData.FormID = "1";
                return this._service.updateProfileAsw(
                  updateData,
                  this.loginService.profileDetail.linkedProfileID
                );
              })
            );
          }
          return of(null);
        })
      )
      .subscribe((data) => {
        this.errorService.sweetAlertConfirm(
          "",
          "Profile updated",
          "",
          this.loginService.theme
        );
      });
  }

  onSubmit(profileDetails: any) {
    this.profileUpdateSubject$.next(profileDetails);
  }

  onSubmit1(profileDetails: any) {
    // this.profileUpdateSubject$.next(profileDetails);
    this.branchID
      ? (profileDetails.Hierarchy = this.branchID)
      : (profileDetails.Hierarchy = "");
    for (const key in this.profile) {
      if (!(key in profileDetails) && key != "Age") {
        profileDetails[key] = this.profile[key];
      } else if (key == "Age" && this.profile[key]) {
        profileDetails[key] = this.profile[key];
      }
    }
    if (
      profileDetails["National ID"] == null ||
      profileDetails["National ID"] == "null"
    ) {
      profileDetails["National ID"] = "";
    }
    profileDetails.profileFormID
      ? (profileDetails.FormID = profileDetails.profileFormID)
      : "";
    profileDetails.profileFormID ? delete profileDetails.profileFormID : "";
    this.profileForm.forEach((label) => {
      if (label.Type == "Date" || label.Type == "date") {
        if (
          this.ngbDateParserFormatter.format(profileDetails[label["Label"]]) !=
          "undefined--"
        ) {
          profileDetails[label["Label"]] = profileDetails[label["Label"]]
            ? new Date(
                this.ngbDateParserFormatter.format(
                  profileDetails[label["Label"]]
                )
              )
                .toISOString()
                .split("T")[0]
            : "";
        }
      }
    });

    this._service
      .updateProfile(
        JSON.stringify(profileDetails),
        this.loginService.profile["details"][0]["profileID"]
      )
      .subscribe(() => {});
  }

  parse(value: string): NgbDateStruct {
    if (!value) return null;
    let parts = value.split("-");
    return {
      year: +parts[0],
      month: +parts[1],
      day: +parts[2],
    } as NgbDateStruct;
  }

  upload(type) {
    if (type == "profilePicture") {
      if (!!this.profPhoto) {
        this.uploadFile(type, this.profPhoto);
      }
    } else {
      if (!!this.documentFile) {
        this.uploadFile(type, this.documentFile);
      }
    }
  }

  uploadFile(type, file) {
    if (type == "profilePicture") this.progressProfilePicture = 1;
    else this.progress = 1;

    const doc = new FormData();

    doc.append("files", file, file.name + "_" + new Date().toISOString());

    const uploadFile$ = this._service
      .uploadFilesToProfile(
        this.loginService.profileDetail.profileID,
        type,
        doc
      )
      .pipe(
        map((event: any) => {
          switch (event.type) {
            case HttpEventType.UploadProgress:
              {
                if (type == "profilePicture")
                  this.progressProfilePicture = Math.round(
                    (100 / event.total) * event.loaded
                  );
                else
                  this.progress = Math.round(
                    (100 / event.total) * event.loaded
                  );
              }
              break;
            case HttpEventType.Response: {
              this.progress = null;
              this.progressProfilePicture = null;
              this.init(this.loginService.profileDetail.profileID);

              this.errorService.sweetAlertConfirm(
                "",
                "Successfully uploaded",
                "",
                this.loginService.theme
              );
              if (type == "profilePicture") this.profPhoto = null;
              else this.documentFile = null;
              return event;
            }
          }

          // if (event.type == HttpEventType.UploadProgress) {
          //   if (type == "profilePicture")
          //     this.progressProfilePicture = Math.round(
          //       (100 / event.total) * event.loaded
          //     );
          //   else this.progress = Math.round((100 / event.total) * event.loaded);
          // } else if (event.type == HttpEventType.Response) {
          //   if (type == "profilePicture") {
          //     this.profPhoto = null;

          //     this.progressProfilePicture = null;
          //   } else {
          //     this.documentFile = null;

          //     this.progress = null;
          //   }
          // this.errorService.sweetAlertConfirm(
          //   "",
          //   "Successfully uploaded",
          //   "",
          //   this.loginService.theme
          // );
          // }
        })
      )
      .subscribe(
        (event) => {
          console.log(event);
        },
        (error) => {
          this.progress = null;
          this.progressProfilePicture = null;
        }
      );

    this.subscription.push(uploadFile$);
  }

  selectFile(event, label) {
    let regex: RegExp = /[^\s]\.+(jpg|jpeg|png|pdf)$/i;
    if (regex.test(event.target.files[0].name)) {
      if (this.fileSize.getFileSize(event.target.files[0].size) < 501) {
        this.fileSizeExceeded = false;

        this.documentFileSize = this.fileSize.transform(
          event.target.files[0].size,
          "KB"
        );

        this.documentFile = event.target.files[0];
      } else {
        this.fileSizeExceeded = true;

        this.documentFileSize = "";
        this.documentFile = null;
      }
    } else {
      console.log("not allowed");
      this.documentFileSize = "";
      this.documentFile = null;
    }
  }

  selectPicture(event) {
    let regex: RegExp = /[^\s]\.+(jpg|jpeg|png|pdf)$/i;
    if (regex.test(event.target.files[0].name)) {
      this.filePreviewAvailable = false;

      if (this.fileSize.getFileSize(event.target.files[0].size) < 501) {
        this.profPhoto = event.target.files[0];

        this.photoSizeExceeded = false;

        this.profilePictureFileSize = this.fileSize.transform(
          event.target.files[0].size,
          "KB"
        );

        let reader = new FileReader();

        let file = event.target.files[0];

        reader.readAsDataURL(file);
        reader.onload = () => {
          this.filePreview =
            "data:image/png" +
            ";base64," +
            (reader.result as string).split(",")[1];
        };
      } else {
        this.photoSizeExceeded = true;

        this.profilePictureFileSize = "";
        this.profPhoto = null;
      }
    } else {
      this.profPhoto = null;
      this.profilePictureFileSize = "";
    }
  }

  /**
   To view image in full screen
   @public
  */
  public viewImage(): void {
    this.appComponent.showImage = true;
    this.appComponent.fileName = this.profile.hasOwnProperty("profilePicture")
      ? this.profile["profilePicture"].substring(
          this.imgUrl.lastIndexOf("/") + 1
        )
      : "";
    this.appComponent.imageUrl = this.imgUrl;
    this.loginService.hideBodyScroll();
  }

  filterBranch(name) {
    this.showBranch = true;
    let branchName: string = name;
    name.length < 4 ? (this.filterChk = "") : "";
    if (name.length > 3) {
      if (
        this.filterChk != "" &&
        name.includes(this.filterChk) &&
        this.dropDownColumnsFull.length != 0
      ) {
        this.dropDownColumns = this.dropDownColumnsFull.filter((col) =>
          col.branch_name.toLowerCase().includes(name.toLowerCase())
        );
      } else {
        this.dropDownColumns = [];
        this._service.searchBranchName(name).subscribe((res) => {
          this.dropDownColumns = res["data"]["portfolio"];
          this.dropDownColumnsFull = res["data"]["portfolio"];
        });
      }
      this.filterChk == "" ? (this.filterChk = name) : "";
    } else {
      this.dropDownColumns = [];
    }
  }

  branchDeselect(item: any, item1: any) {
    this.showBranch = false;
    this.branchID = item;
    this.hierarchyName = item1;
  }

  private parseDatePicker(dateObj: ParseDate): string {
    if (!dateObj) return null;
    let parts = `${dateObj.year}-${dateObj.month}-${dateObj.day}`;
    return parts;
  }

  sanitize(url: string) {
    return this.sanitizer.bypassSecurityTrustUrl(url);
  }

  ngOnDestroy(): void {
    if (this.subscription.length > 0) {
      this.subscription.forEach((subs) => {
        if (subs) subs.unsubscribe();
      });
    }
    this.destroy$.next();
  }
}
