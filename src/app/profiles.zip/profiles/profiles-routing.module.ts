import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { EditProfileComponent } from "./edit-profile/edit-profile.component";
// import { EditProfileComponent } from "./edit-profile/edit-profile.component.ts-old";

const routes: Routes = [
  {
    path: "",
    children: [
      {
        path: "edit-client",
        component: EditProfileComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProfilesRoutingModule {}
export const routedComponents = [EditProfileComponent];
