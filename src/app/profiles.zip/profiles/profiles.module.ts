import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import {
  ProfilesRoutingModule,
  routedComponents,
} from "./profiles-routing.module";
import { Ng2SmartTableModule } from "ng2-smart-table";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { FormsModule } from "@angular/forms";
import { ExpandMode, NgxTreeSelectModule } from "ngx-tree-select";
import { DocumentStorageService } from "../document-storage/document-storage.service";
import { AppService } from "../app.service";
import { ProfileService } from "./profile.service";

@NgModule({
  imports: [
    CommonModule,
    ProfilesRoutingModule,
    Ng2SmartTableModule,
    NgbModule,
    FormsModule,
    NgxTreeSelectModule.forRoot({
      idField: "branchid",
      textField: "branch_name",
      expandMode: ExpandMode.Selection,
    }),
  ],
  declarations: [...routedComponents],
  providers: [ProfileService, DocumentStorageService, AppService],
})
export class ProfilesModule {}
