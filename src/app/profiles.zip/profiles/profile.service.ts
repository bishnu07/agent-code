import { Injectable } from "@angular/core";
import { Http, Response, Headers, RequestOptions } from "@angular/http";
import { AppService } from "../app.service";
import { LoginService } from "../shared/services/login.service";
import swal from "sweetalert2";
import { Observable } from "rxjs/Observable";
import "rxjs/add/operator/map";
import { BranchesService } from "app/branches/branches.service";
import { OnBoardService } from "app/on-board/on-board.service";
import {
  HttpBackend,
  HttpClient,
  HttpHeaders,
  HttpResponse,
} from "@angular/common/http";

@Injectable()
export class ProfileService {
  // public profileId: any;
  public profileFormId: any;
  public branches: any;
  public profileFormData: any;
  public access_token: any;
  public baseUrl: any;
  public treeLevel;
  public baseLink;
  private headers = new Headers({
    "Content-Type": "application/json",
  });
  private options = new RequestOptions({ headers: this.headers });

  private httpHeaders = new HttpHeaders({
    "Content-Type": "application/json",
    Accept: "application/json",
  });

  constructor(
    private _http: Http,
    private commonservice: AppService,
    private branchService: BranchesService,
    public onboardService: OnBoardService,
    private loginService: LoginService,
    private _httpClient: HttpClient,
    private _httpClientHandler: HttpBackend
  ) {
    this.baseUrl =
      this.loginService.urlNumber() +
      ":" +
      this.loginService.portnumber() +
      "/ProfileService";
    this.access_token = loginService.access_tokenMethod();
    this.baseLink = this.profilePort();
    this._httpClient1 = new HttpClient(this._httpClientHandler);
  }

  portfolioport() {
    return (
      this.loginService.urlNumber() +
      ":" +
      this.loginService.portnumber() +
      "/PortfolioService"
    );
  }

  profilePort() {
    return (
      this.loginService.urlNumber() +
      ":" +
      this.loginService.portnumber() +
      "/ProfileService"
    );
  }

  createProfile(selectProfile) {
    return this._http
      .post(
        this.profilePort() + "/profiles?access_token=" + this.access_token,
        selectProfile,
        this.options
      )
      .map((res: Response) => res.json());
  }

  createProfileform(selectProfileForm) {
    return this._http
      .post(
        this.profilePort() +
          "/profiles/forms?access_token=" +
          this.access_token,
        selectProfileForm,
        this.options
      )
      .map((res: Response) => res.json());
  }

  getLogo() {
    return this._httpClient
      .get(
        `${this.profilePort()}/logos/${this.loginService.rootUserID}/personal`
      )
      .map((res: HttpResponse<any>) => res);
  }

  searchBranchName(branchName) {
    return this._http
      .get(
        this.portfolioport() +
          "/hierarchySearch?access_token=" +
          this.access_token +
          (branchName ? "&branchName=" + branchName : ""),
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  provideProfileFormByFormID(profileID) {
    return this._httpClient
      .get(`${this.profilePort()}/profiles/forms/${profileID}`)
      .map((res: HttpResponse<any>) => res);
  }

  provideProfile() {
    return this._http
      .get(
        this.profilePort() + "/profiles?access_token=" + this.access_token,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  provideProfilePagination(pgNum, records) {
    // return this._http
    //   .get(
    //     this.profilePort() +
    //       "/profiles?pageNumber=" +
    //       pgNum +
    //       "&numberOfRecords=" +
    //       records +
    //       "&access_token=" +
    //       this.access_token,
    //     this.options
    //   )
    //   .map((response: Response) => response.json())
    //   .catch(this.errorHandler);

    return this._httpClient
      .get(
        `${this.profilePort()}/profiles?pageNumber=${pgNum}&numberOfRecords=${records}`
      )
      .map((response: HttpResponse<any>) => response)
      .catch(this.errorHandler);
  }

  provideProfileById(ProfileID) {
    // return this._http
    //   .get(
    //     this.profilePort() +
    //       "/profiles/" +
    //       ProfileID +
    //       "?access_token=" +
    //       this.access_token,
    //     this.options
    //   )
    //   .map((response: Response) => response.json())
    //   .catch(this.errorHandler);
    return this._httpClient
      .get(`${this.profilePort()}/profiles/${ProfileID}`)
      .map((response: HttpResponse<any>) => response)
      .catch(this.errorHandler);
  }

  filterProfiles(filterData) {
    return this._http
      .get(
        this.profilePort() +
          "/searchProfiles?" +
          (filterData.Branch ? "&branchId=" + filterData.Branch + "&" : "") +
          (filterData.Identifier
            ? "&identifier=" + filterData.Identifier
            : "") +
          (filterData.Hierarchy ? "&Hierarchy=" + filterData.Hierarchy : "") +
          (filterData.Name ? "&name=" + filterData.Name : "") +
          (filterData.profileID ? "&profileId=" + filterData.profileID : "") +
          (filterData.linkedProfileID
            ? "&linkedProfileId=" + filterData.linkedProfileID
            : "") +
          (filterData.NationalID
            ? "&nationalId=" + filterData.NationalID
            : "") +
          "&access_token=" +
          this.access_token,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  provideLinkMenuToRole(roleId) {
    // return this._http
    //   .get(
    //     this.commonservice.rootURL +
    //       "/provideLinkMenuToRole?access_token=" +
    //       this.access_token +
    //       (roleId ? "&roleId=" + roleId : "&roleId="),
    //     this.options
    //   )
    //   .map((res: Response) => res.json())
    //   .catch(this.errorHandler);
    return this._httpClient
      .get(
        this.commonservice.rootURL +
          "/provideLinkMenuToRole?" +
          (roleId ? "roleId=" + roleId : "roleId=")
      )
      .map((res: HttpResponse<any>) => res)
      .catch(this.errorHandler);
  }

  filterProfilesWithPagination(filterData, pgNo, noOfRecords) {
    return this._http
      .get(
        this.profilePort() +
          "/searchProfiles?" +
          (filterData.Branch ? "&branchId=" + filterData.Branch + "&" : "") +
          (filterData.Identifier
            ? "&identifier=" + filterData.Identifier
            : "") +
          (filterData.Hierarchy ? "&Hierarchy=" + filterData.Hierarchy : "") +
          (filterData.Name ? "&name=" + filterData.Name : "") +
          (filterData.profileID ? "&profileId=" + filterData.profileID : "") +
          (filterData.linkedProfileID
            ? "&linkedProfileId=" + filterData.linkedProfileID
            : "") +
          (filterData.NationalID
            ? "&nationalId=" + filterData.NationalID
            : "") +
          "&access_token=" +
          this.access_token +
          "&pageNumber=" +
          pgNo +
          "&numberOfRecords=" +
          noOfRecords,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  getProfileForms() {
    return this._http
      .get(
        this.profilePort() +
          "/profiles/forms?access_token=" +
          this.access_token,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  deleteProfile(profileId) {
    return this._http
      .delete(
        this.profilePort() +
          "/profiles/" +
          profileId +
          "?access_token=" +
          this.access_token,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  updateProfile(selectProfile, ProfileID) {
    return this._http
      .put(
        this.profilePort() +
          "/profiles/" +
          ProfileID +
          "?access_token=" +
          this.access_token,
        selectProfile,
        this.options
      )
      .map((res: Response) => res.json())
      .catch(this.errorHandler);
  }

  updateProfileForm(selectProfileForm, profileFormId) {
    return this._http
      .put(
        this.profilePort() +
          "/profiles/forms/" +
          profileFormId +
          "?access_token=" +
          this.access_token,
        selectProfileForm,
        this.options
      )
      .map((res: Response) => res.json());
  }

  provideProfileFormById(profileFormId) {
    return this._httpClient
      .get(`${this.profilePort()}/profiles/forms/${profileFormId}`)
      .map((response: HttpResponse<any>) => response)
      .catch(this.errorHandler);
  }

  deleteProfileForm(profileFormId) {
    return this._http
      .delete(
        this.profilePort() +
          "/profiles/forms/" +
          profileFormId +
          "?access_token=" +
          this.access_token,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  provideAllCountry() {
    return this._http
      .get(
        this.profilePort() + "/country?access_token=" + this.access_token,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  ProviceStateByCountryID(countryID) {
    return this._http
      .get(
        this.profilePort() +
          "/state/" +
          countryID +
          "?access_token=" +
          this.access_token,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  ProviceCityByStateID(stateID) {
    return this._http
      .get(
        this.profilePort() +
          "/city/" +
          stateID +
          "?access_token=" +
          this.access_token,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  getBranches(branchLevel) {
    return this._httpClient
      .get(
        `${this.branchService.branchPort()}/getBranchByBranchLevel/${branchLevel}`
      )
      .map((response: HttpResponse<any>) => response)
      .catch(this.errorHandler);
  }

  getAllBranches() {
    return this._http
      .get(
        this.profilePort() +
          "/branches/hierarchy?access_token=" +
          this.access_token,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  getAllBranchNames() {
    return this._httpClient
      .get(`${this.portfolioport()}/hierarchySearch`)
      .map((response: HttpResponse<any>) => response)
      .catch(this.errorHandler);
  }

  getAllBranchesTree() {
    return this._http
      .get(
        this.branchService.branchPort() +
          "/getAllTreeLevelBranches?access_token=" +
          this.access_token,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  getAllBranches1(branchid) {
    return this._http
      .get(
        this.profilePort() +
          "/branches/hierarchy?access_token=" +
          this.access_token +
          "&branchid=" +
          branchid,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  getBranchGroup(branchID) {
    return this._http
      .get(
        this.profilePort() +
          "/getTreeLevelBranchByBranchId/" +
          branchID +
          "?access_token=" +
          this.access_token,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  getBranchByID(branchID) {
    return this._http
      .get(
        this.profilePort() +
          "/provideBranch/" +
          branchID +
          "?access_token=" +
          this.access_token
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  getBranchesTree() {
    return this._http
      .get(
        this.profilePort() +
          "/branches/treeLevel?access_token=" +
          this.loginService.access_token,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  getBranchTree() {
    return this._http
      .get(
        this.branchService.branchPort() +
          "/branches/treeLevel?access_token=" +
          this.loginService.access_token,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  getAllBranchesTreeLevel() {
    return this._http
      .get(
        this.branchService.branchPort() +
          "/getAllTreeLevelBranches?access_token=" +
          this.loginService.access_token,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  searchApprovalProfiles(profileids, approved) {
    return this._http
      .get(
        this.profilePort() +
          "/searchapprovalProfiles?profileIds=" +
          profileids +
          "&access_token=" +
          this.access_token +
          (approved ? "&approved=" + approved : "&approved=")
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  getTreeHIerarchy() {
    return this._http
      .get(
        this.profilePort() +
          "/branches/treeHierarchy?access_token=" +
          this.access_token
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  getProfiles() {
    return this._http
      .get(
        this.profilePort() + "/profiles?access_token=" + this.access_token,
        this.options
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  uploadFilesToProfile(pID, type, value, access_token?: any, callUrl?: any) {
    if (!access_token) {
      return this._httpClient
        .post(`${this.baseUrl}/upload/files/${pID}/${type}`, value, {
          reportProgress: true,
          observe: "events",
          headers: {
            "Hide-Loader": "true",
            "Content-Type": "multipart/form-data",
          },
        })
        .map((res: HttpResponse<any>) => res)
        .catch(this.errorHandler);
    } else {
      return this._httpClient
        .post(
          `${callUrl}:5055/ProfileService/upload/shufti/files/${pID}/${type}`,
          value
        )
        .map((res: HttpResponse<any>) => res)
        .catch(this.errorHandler);
    }
  }

  uploadFilesToProfile1(pID, type, value) {
    return this._http
      .post(
        this.baseUrl +
          "/upload/files/" +
          pID +
          "/" +
          type +
          "?access_token=" +
          this.access_token,
        value
      )
      .map((res: Response) => res.json())
      .catch(this.errorHandler);
  }

  getFileList(profID, type) {
    return this._httpClient
      .get(`${this.baseUrl}/files/${profID}/${type}`)
      .map((response: HttpResponse<any>) => response["data"]["documents"]);
  }

  getFile(profID, type, fileName) {
    return this._http
      .get(
        this.baseUrl +
          "/downloadFile/" +
          profID +
          "/" +
          type +
          "/" +
          fileName +
          "?access_token=" +
          this.access_token
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  createProfileAsw(selectProfile) {
    return this._http
      .post(
        this.loginService.ProfileUrl +
          "/profiles?access_token=" +
          this.loginService.access_token_asw,
        selectProfile
      )
      .map((res: Response) => res.json())
      .catch(this.errorHandler);
  }

  updateProfileAsw(profileDetails, profID) {
    return this._httpClient
      .put(
        `${this.loginService.PROFILE_URL}/profiles/${profID}`,
        profileDetails
      )
      .map((res: HttpResponse<any>) => res)
      .catch(this.errorHandler);
  }

  addLinkedProfileToProfile(profID, linkedProfID) {
    return this._http
      .put(
        this.profilePort() +
          "/profile/" +
          profID +
          "/linkedProfile/" +
          linkedProfID +
          "?access_token=" +
          this.access_token,
        this.options
      )
      .map((res: Response) => res.json())
      .catch(this.errorHandler);
  }

  getWorkflowsCount() {
    return this._http
      .get(
        this.onboardService.profilePort() +
          "/workflows/count?access_token=" +
          this.loginService.access_token
      )
      .map((response: Response) => {
        return response.json()["data"]["workflow"];
      })
      .catch(this.errorHandler);
  }

  getDelinquencyCount(date) {
    return this._http
      .get(
        this.portfolioport() +
          "/contracts/delinquency/report/" +
          date +
          "?access_token=" +
          this.loginService.access_token
      )
      .map((response: Response) => response.json()["data"]["portfolio"])
      .catch(this.errorHandler);
  }

  getPendingDisCount() {
    return this._http
      .get(
        this.portfolioport() +
          "/widget1?access_token=" +
          this.loginService.access_token
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  getWidget3() {
    return this._httpClient
      .get(`${this.loginService.CONTRACT_URL}/contracts/count`)
      .map((response: HttpResponse<any>) => response)
      .catch(this.errorHandler);
  }

  getRepaymentsCount() {
    return this._http
      .get(
        this.portfolioport() +
          "/widget2?access_token=" +
          this.loginService.access_token
      )
      .map((response: Response) => response.json())
      .catch(this.errorHandler);
  }

  errorHandler(error) {
    let errorMessage = JSON.parse(error._body);
    if (errorMessage.status != 200) {
      swal("Sorry!", errorMessage.message, "error");
    }
    // if (error.error instanceof ErrorEvent) {
    //   // A client-side or network error occurred. Handle it accordingly.
    //   console.error('An error occurred:', error.error.message);
    // }
    // return throwError(
    //   'Something bad happened; please try again later.');

    return Observable.throwError(error);
  }
}
